# Outer-in Prime-Support Research

## Current research object

For a decimal integer

\[
n=d_1d_2\ldots d_k,
\]

define the **outer-in digit transformation**

\[
T(n)=d_1d_kd_2d_{k-1}d_3d_{k-2}\ldots.
\]

The research problem is to find nontrivial integers satisfying

\[
n\ne T(n)
\]

and

\[
\operatorname{rad}(n)=\operatorname{rad}(T(n)),
\]

where

\[
\operatorname{rad}(m)=\prod_{p\mid m}p
\]

is the product of the distinct prime divisors of \(m\).

A **primitive** solution, for the present computational study, is one for which \(n\) does not end in zero.

## Status of this snapshot

This is an internal research snapshot dated **2026-09-22**.

It deliberately distinguishes:

- results proved mathematically;
- results obtained by globally exhaustive computation in a stated range;
- examples found by searches restricted to already-known reduced ratios;
- conjectures and open questions.

The 36 examples in `data/known_primitive_examples.csv` are all independently verified by the separate verifier program used in this project.

**Important:** the 36 examples are not claimed to be the complete primitive sequence. The globally exhaustive computation currently establishes the primitive list only below \(10^9\). Larger examples have been found through ratio-restricted searches.

## Exact gcd/radical criterion

Let

\[
g=\gcd(n,T(n)),
\]

and write

\[
n=ag,\qquad T(n)=bg,\qquad \gcd(a,b)=1.
\]

Then

\[
\operatorname{rad}(n)=\operatorname{rad}(T(n))
\]

is equivalent to

\[
\operatorname{rad}(ab)\mid g.
\]

Equivalently,

\[
a\,\operatorname{rad}(ab)\mid n.
\]

This criterion is used to test prime-support preservation once the reduced ratio \(a:b\) is known.

## Proven infinite families

Let

\[
Q_r=\frac{10^{6r}-1}{999}
     =1+10^3+10^6+\cdots+10^{6r-3}.
\]

Then \(224Q_r\) is the decimal integer consisting of \(2r\) repetitions of the block `224`, and

\[
T(224Q_r)=242Q_r.
\]

Likewise,

\[
T(448Q_r)=484Q_r.
\]

Because

\[
1000\equiv -1\pmod{77},
\]

the sum defining \(Q_r\) contains an even number \(2r\) of alternating terms modulo \(77\), hence

\[
77\mid Q_r.
\]

Since

\[
224=2^5\cdot7,\qquad 242=2\cdot11^2,
\]

both members have the same distinct prime divisors after multiplication by \(Q_r\). The same argument applies to \(448\) and \(484\).

Therefore, for every \(r\ge1\),

\[
224Q_r\to242Q_r
\]

and

\[
448Q_r\to484Q_r
\]

are primitive solutions.

Known members in this snapshot include 6, 12, 18, 24 and 30 decimal digits.

## Globally exhaustive computation

The original primitive search established all primitive solutions with

\[
n<10^9.
\]

There are 19 such solutions:

`3024, 6048, 10143, 20286, 27864, 117216, 189216, 224224, 333234, 352872, 387585, 448448, 666468, 3892032, 3928824, 137539323, 247153125, 321881616, 869148324`.

The corresponding search code is retained in `code/search.cpp` and the accelerated 9-digit implementation in `code/search_9digit_fast.cpp`.

## Ratio-restricted discoveries

For a solution,

\[
n:T(n)=a:b
\]

after reducing the pair by their gcd.

The current verified examples occupy 12 observed reduced-ratio classes:

\[
8:9,\ 7:9,\ 9:8,\ 8:11,\ 112:121,\ 33:34,
\]

\[
13:12,\ 27:25,\ 32:27,\ 2257:2187,\ 625:643,\ 1331:1296.
\]

These are the ratios observed so far, not a proof that no other ratio can occur.

## Computational methodology

The project developed in stages:

1. direct exhaustive search for small integers;
2. accelerated digit-filtered search through \(10^9\);
3. orbit analysis under repeated application of \(T\);
4. carry-based solvers for fixed reduced ratios;
5. arbitrary-precision ratio-restricted searches;
6. an independent verifier that recomputes \(T(n)\), gcds, reduced ratios and the exact radical criterion.

All incomplete searches are recorded as incomplete and are not interpreted as negative results.

## Current open questions

1. What reduced ratios are possible at all?
2. Can the observed ratio classes be classified?
3. Which classes have infinite families?
4. Are there additional repeated-block constructions?
5. Does every nontrivial orbit contain at most one adjacent prime-support-preserving edge?
6. Can a globally exhaustive search be extended far beyond \(10^9\) without prespecifying the ratio?
7. What is the complete primitive sequence?
8. What is the corresponding full sequence when trailing zeros are allowed?

## Related work

A closely related established problem studies numbers whose decimal reversal has the same prime divisors; see OEIS A110751. The present transformation is different.

The multiplication relation between a number and a digit permutation is part of the broader theory of **permutiples**, including carry-based and finite-state methods. See Benjamin V. Holt, *On Permutiples Having a Fixed Set of Digits*, arXiv:1511.02033, and subsequent work by Holt on finite-state methods for permutiples.

No claim of priority or of being the first study of the exact present problem is made in this snapshot.

## Reproducibility

The repository keeps:

- source programs;
- raw result files;
- independently verified candidate data;
- search logs;
- this research snapshot.

The code should be compiled and run from the documented commands in the research log. Search results carry an explicit `COMPLETE` or `INCOMPLETE` status.
