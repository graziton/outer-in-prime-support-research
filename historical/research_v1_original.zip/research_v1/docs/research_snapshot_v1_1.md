# Research Snapshot v1.1 — 2026-09-22

## Purpose

This document records the state of an ongoing computational number-theory investigation. It is a research snapshot, not a claim of a complete classification.

The snapshot separates mathematical proofs, exhaustive computations, verified examples, observations, and conjectures.

## 1. Problem definition

For a decimal integer with digit string

\[
n=d_1d_2\ldots d_k,
\]

define the outer-in digit transformation

\[
T(n)=d_1d_kd_2d_{k-1}d_3d_{k-2}\ldots.
\]

The main property under study is

\[
n\ne T(n)
\]

together with

\[
\operatorname{rad}(n)=\operatorname{rad}(T(n)),
\]

where

\[
\operatorname{rad}(m)=\prod_{p\mid m}p
\]

is the product of the distinct prime divisors of \(m\).

For the present exploratory dataset, a solution is called **primitive** when the original decimal representation of \(n\) does not end in zero. This is a computational restriction used to suppress trailing-zero families; it is not part of the main definition.

## 2. Exact algebraic criterion

Let

\[
g=\gcd(n,T(n)),
\]

and write

\[
n=ag,\qquad T(n)=bg,\qquad \gcd(a,b)=1.
\]

Then

\[
\operatorname{rad}(n)=\operatorname{rad}(T(n))
\]

if and only if

\[
\operatorname{rad}(ab)\mid g.
\]

### Proof

Every prime dividing \(g\) divides both \(n\) and \(T(n)\).

Because \(\gcd(a,b)=1\), a prime dividing \(a\) cannot divide \(b\). If such a prime did not divide \(g\), it would divide \(n\) but not \(T(n)\), contradicting equality of prime supports. The same applies to primes dividing \(b\). Hence support equality implies

\[
\operatorname{rad}(ab)\mid g.
\]

Conversely, if every prime dividing \(a\) or \(b\) already divides \(g\), then both \(ag\) and \(bg\) have exactly the prime support contributed by \(g\), together with no additional primes. Hence their prime supports are equal.

Therefore the criterion is exact.

An equivalent divisibility condition is

\[
a\,\operatorname{rad}(ab)\mid n.
\]

## 3. Proven infinite families

Define

\[
Q_r=\frac{10^{6r}-1}{999}
    =1+10^3+10^6+\cdots+10^{6r-3},
\qquad r\ge1.
\]

Thus \(Q_r\) is a string of \(2r\) blocks of `1` separated by three decimal positions, and

\[
224Q_r
\]

is the decimal number formed by repeating the block `224` exactly \(2r\) times.

Likewise \(448Q_r\) repeats the block `448` exactly \(2r\) times.

Directly from the definition of \(T\),

\[
T(224Q_r)=242Q_r
\]

and

\[
T(448Q_r)=484Q_r.
\]

Moreover,

\[
1000\equiv-1\pmod{77}.
\]

The sum defining \(Q_r\) has \(2r\) terms, so the terms alternate \(1,-1,1,-1,\ldots\) modulo \(77\) and cancel in pairs. Therefore

\[
77\mid Q_r.
\]

Now

\[
224=2^5\cdot7,\qquad 242=2\cdot11^2,
\]

so both \(224Q_r\) and \(242Q_r\) contain the primes \(2,7,11\), together with every prime dividing \(Q_r\). Hence they have identical sets of distinct prime divisors.

Similarly,

\[
448=2^6\cdot7,\qquad 484=2^2\cdot11^2,
\]

so \(448Q_r\) and \(484Q_r\) have identical prime support.

Therefore the following are proven infinite families of primitive solutions:

\[
\boxed{224Q_r\longrightarrow242Q_r}
\]

and

\[
\boxed{448Q_r\longrightarrow484Q_r}
\]

for every \(r\ge1\).

The reduced ratio in both families is

\[
112:121.
\]

## 4. Current known verified examples

The file `data/known_primitive_examples.csv` contains 36 **distinct** primitive examples.

All 36 have been independently checked by the separate verifier program and returned `VERIFIED`.

They are **known verified examples**, not claimed to be the complete primitive sequence.

The current 36 examples occupy the following observed reduced-ratio classes:

| Ratio | Count |
|---|---:|
| 8:9 | 8 |
| 7:9 | 2 |
| 9:8 | 5 |
| 8:11 | 1 |
| 112:121 | 10 |
| 33:34 | 2 |
| 13:12 | 2 |
| 27:25 | 1 |
| 32:27 | 2 |
| 2257:2187 | 1 |
| 625:643 | 1 |
| 1331:1296 | 1 |
| **Total** | **36** |

The ratio list is observational: it records ratios appearing in the currently known examples and is not a proof that these are the only possible ratios.

## 5. Exhaustive computation established so far

The original primitive exhaustive search establishes the complete primitive list for

\[
n<10^9.
\]

There are 19 such solutions:

\[
3024,\ 6048,\ 10143,\ 20286,\ 27864,\ 117216,\ 189216,
\]

\[
224224,\ 333234,\ 352872,\ 387585,\ 448448,\ 666468,
\]

\[
3892032,\ 3928824,\ 137539323,\ 247153125,\ 321881616,\ 869148324.
\]

This completeness claim applies only to the stated range and primitive restriction.

For \(n\ge10^9\), additional examples have been discovered by searches restricted to already-observed reduced ratios. Those searches do not rule out smaller examples belonging to as-yet-unobserved ratios.

Consequently, the 36-example file is not an ordered complete sequence beyond \(10^9\).

## 6. Higher-digit fixed-ratio computation

The current carry-based program has been run for several observed ratios at 25–30 digits.

A result marked `COMPLETE` means the program exhausted its search space for that ratio and digit length under its implementation. `INCOMPLETE` means a node cap was reached and no negative conclusion is justified.

Observed examples:

- \(8:9\): 27 digits produced one genuine support match; 25, 26, 28, 29 and 30 digits produced no ratio solution in the completed searches.
- \(9:8\): 25–30 digits produced no ratio solutions in the completed searches.
- \(7:9\): 25–30 digits produced no ratio solutions in the completed searches.
- \(8:11\): 25–30 digits produced no ratio solutions in the completed searches.
- \(33:34\): 27 and 30 digits each produced a ratio solution, but neither was a support match; the other completed lengths in the tested range produced none.
- \(13:12\): 27 digits produced one genuine support match; 26 digits produced a ratio solution without support match; 25, 28 and 29 digits produced none; the 30-digit run was incomplete at the time of this snapshot.
- \(112:121\): the search also encounters ratio-only solutions which need not have the required prime support. Independent mathematical proof supplies an infinite support-preserving family in this class, so an incomplete computational search at a family length is not evidence against existence.

These statements concern only the fixed ratios and lengths actually tested.

## 7. Independent verification

A separate program, `code/verify_solutions.cpp`, recomputes \(T(n)\) from the decimal digits and independently checks the exact prime-support criterion through the gcd/reduced-ratio formulation.

The initial 32-candidate audit returned:

- Candidates read: 32
- Verified matches: 32
- Non-verified outcomes: 0

The expanded 36-example audit also returned all entries as verified.

Verification artifacts are retained under `data/` and `logs/`.

## 8. Computational observations

The following are observations rather than theorems:

- Prime-support-preserving examples are sparse among the fixed-ratio digit-permutation solutions examined so far.
- Different reduced ratios exhibit different digit-length behavior.
- The \(112:121\) class contains a simple repeated-block infinite family.
- In the orbit computations performed so far, no nontrivial orbit was observed to contain two consecutive prime-support-preserving edges.

The last point is currently only computational evidence for a possible conjecture.

## 9. Current conjectures and open questions

The following remain open in this project:

1. Which reduced ratios \(a:b\) are possible?
2. Are there additional ratios beyond those currently observed?
3. Which ratio classes contain infinite families?
4. Can all repeated-block families be characterized?
5. Is every nontrivial \(T\)-orbit limited to at most one adjacent support-preserving edge?
6. Can a ratio-independent search establish a substantially larger complete initial segment of the primitive sequence?
7. What is the complete primitive sequence?
8. What is the corresponding sequence without the primitive restriction?

## 10. Novelty status

The current work should use the cautious formulation **“apparently unrecorded in the searches performed so far.”**

A related established problem concerns equality of prime divisors under ordinary decimal reversal. The broader theory of digit-permutation multiplication also contains closely related objects.

The present project therefore does **not** claim that the exact problem is the first or only investigation of this type. A more extensive literature and OEIS search is planned before any public priority or novelty claim.

## 11. Research status on 2026-09-22

### Proved

- definition of \(T\);
- exact gcd/radical criterion;
- two explicit infinite \(112:121\) repeated-block families.

### Globally exhaustively computed

- primitive solutions below \(10^9\).

### Independently verified

- 36 distinct known primitive examples.

### Ratio-restricted computational discoveries

- additional solutions above \(10^9\), including 27-digit examples.

### Not proved

- completeness beyond \(10^9\);
- classification of ratios;
- classification of all infinite families;
- orbit uniqueness;
- complete novelty/priority of the exact problem.

## 12. Next research stage

The central computational gap is that the higher-digit searches have so far been restricted to ratios already discovered.

The next major technical objective is therefore a **ratio-independent carry/state search** that can discover or rule out solutions without assuming the reduced ratio in advance.

A public OEIS submission should be prepared only after establishing a sufficiently long complete initial segment of the chosen sequence and completing a broader novelty search.
