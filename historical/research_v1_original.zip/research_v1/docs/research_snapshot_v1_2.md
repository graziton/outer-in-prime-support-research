# Research Snapshot v1.2 — 2026-09-22

## Status

This is an internal research snapshot of an ongoing computational-number-theory investigation. It is not a claim of a complete classification and does not assert priority over all prior work.

## 1. Research object

For a decimal integer with digits

\[
n=d_1d_2\ldots d_k,
\]

define the outer-in digit transformation

\[
T(n)=d_1d_kd_2d_{k-1}d_3d_{k-2}\ldots.
\]

The main property is

\[
n\ne T(n)
\quad\text{and}\quad
\operatorname{rad}(n)=\operatorname{rad}(T(n)),
\]

where \(\operatorname{rad}(m)\) is the product of the distinct prime divisors of \(m\).

For the exploratory primitive dataset, \(n\) is called primitive when its final decimal digit is nonzero. This restriction is computational convenience only.

## 2. Exact algebraic reduction

Let

\[
g=\gcd(n,T(n)),
\qquad
n=ag,\qquad
T(n)=bg,
\qquad
\gcd(a,b)=1.
\]

Then

\[
\operatorname{rad}(n)=\operatorname{rad}(T(n))
\]

if and only if

\[
\operatorname{rad}(ab)\mid g.
\]

Equivalently,

\[
a\operatorname{rad}(ab)\mid n.
\]

This is an exact criterion and is independent of the search implementation.

## 3. Proven universal repeated-block families

A repeated-block construction begins with an \(m\)-digit block \(B\) and an \(m\)-digit block \(C\) satisfying

\[
T(BB)=CC.
\]

For an even number \(2r\) of copies,

\[
T(B^{2r})=C^{2r}.
\]

Writing \(A=[B]\), \(C_0=[C]\), and

\[
Q_r=1+10^m+\cdots+10^{(2r-1)m},
\]

the corresponding integers are

\[
AQ_r,\qquad C_0Q_r.
\]

A universal support-preserving family, valid for every \(r\ge1\), is obtained exactly when

\[
P(A)\triangle P(C_0)
\subseteq P(10^m+1),
\]

where \(P(x)\) denotes the set of distinct prime divisors.

### Family I

\[
224\longrightarrow242.
\]

Since

\[
224=2^5\cdot7,\qquad
242=2\cdot11^2,
\]

the support difference is \(\{7,11\}\), and

\[
10^3+1=1001=7\cdot11\cdot13.
\]

Therefore every even repetition count gives a solution.

### Family II

\[
448\longrightarrow484.
\]

Since

\[
448=2^6\cdot7,\qquad
484=2^2\cdot11^2,
\]

the support difference is again \(\{7,11\}\), supplied by

\[
10^3+1.
\]

Therefore every even repetition count gives a solution.

### Family III

\[
117117117\longrightarrow171171171.
\]

The block values satisfy

\[
117117117=117(1+10^3+10^6),
\]

\[
171171171=171(1+10^3+10^6).
\]

After reduction,

\[
117117117:171171171=13:19,
\]

and the support difference is \(\{13,19\}\).

Also

\[
10^9+1
=
7\cdot11\cdot13\cdot19\cdot52579.
\]

Therefore every even repetition of the 9-digit seed is a primitive prime-support solution.

Equivalently, repeating the digit block `117` a positive multiple of six times gives a solution after applying \(T\), which turns the repeated `117` blocks into repeated `171` blocks.

The first such solution is

\[
117117117117117117
\rightarrow
171171171171171171.
\]

## 4. Current known verified examples

There are currently **39 distinct documented primitive examples** in `data/known_primitive_examples_v2.csv`.

All 39 have been independently verified in this research workflow.

They fall into three provenance categories:

| Provenance | Count |
|---|---:|
| Globally exhaustive below \(10^9\) | 19 |
| Proven repeated-block family | 11 |
| Ratio-restricted discovery | 9 |
| **Total** | **39** |

The 39 examples are known verified examples, not the complete primitive sequence.

## 5. Exhaustive computation currently established

The original primitive exhaustive search establishes the complete primitive list for

\[
n<10^9.
\]

There are 19 solutions in that range.

For values above \(10^9\), additional examples were found using searches restricted to reduced ratios already observed in smaller solutions or by membership in the proven repeated-block families.

Therefore the current 39 examples must not be presented as the first 39 terms of the complete primitive sequence.

## 6. Ratio-restricted higher-digit computations

Fixed-ratio carry searches have been used to explore several observed reduced ratios at 25–30 digits.

A result marked `COMPLETE` is exhaustive for that stated ratio and digit length under the program's search space. An `INCOMPLETE` result means a node cap was reached and does not establish nonexistence.

Important completed observations include:

- \(8:9\): no ratio solutions at 25, 26, 28, 29 or 30 digits; one genuine support match at 27 digits.
- \(9:8\): no ratio solutions at 25–30 digits in the completed searches.
- \(7:9\): no ratio solutions at 25–30 digits in the completed searches.
- \(8:11\): no ratio solutions at 25–30 digits in the completed searches.
- \(33:34\): ratio solutions occurred at 27 and 30 digits but failed the support condition.
- \(13:12\): one genuine support match occurred at 27 digits; the 30-digit search remained incomplete at the time of this snapshot.

These are fixed-ratio observations only.

## 7. Repeated-block search

A constrained exhaustive search through block length 12 found universal repeated-block rows reducing to three underlying constructions:

\[
224\to242,
\]

\[
448\to484,
\]

\[
117117117\to171171171.
\]

Longer rows such as `224224 -> 242242` represent periodic descriptions of the first family rather than additional independent generators.

This finite search does not prove that the three constructions are the only infinite families of the original problem.

## 8. Independent verification

The separate verifier recomputes \(T(n)\) independently and checks the prime-support criterion through the gcd/reduced-ratio formulation.

The expanded 39-example dataset has been independently checked with:

- no duplicate values;
- all entries primitive;
- no fixed points;
- matching transformations;
- prime-support preservation.

## 9. Current observations and conjectures

These are not theorems:

- prime-support-preserving solutions appear sparse among fixed-ratio digit-permutation solutions examined so far;
- the possible reduced ratios may be strongly constrained;
- different ratio classes show different digit-length behavior;
- the repeated-block constructions discovered so far are highly structured;
- no nontrivial orbit examined so far has contained two consecutive support-preserving edges.

## 10. Novelty status

Preliminary searches have not located an OEIS sequence or paper matching the exact combination of this outer-in transformation and equality of distinct prime supports.

This remains a preliminary novelty assessment. The reversal problem and the broader literature on digit-preserving multiplication/permutiples are closely related.

No claim of priority or of absolute originality is made in this snapshot.

## 11. Next research objective

The main remaining computational gap is the lack of a ratio-independent method for larger numbers.

The next major objective is therefore a finite-state/carry search capable of discovering or ruling out solutions without prespecifying a reduced ratio.

Before an OEIS submission, a sufficiently long complete initial segment of the chosen sequence and a broader novelty search should be established.
