# Final Master Submission Guide

This is the final map for the material. No research code needs to be changed.

## A. OEIS submission

Use:

`OEIS_SUBMISSION_FINAL_2026-09-22.txt`

Paste its `%N`, `%C`, `%F`, `%Y`, `%e`, `%S/%T/%U`, `%K`, and `%O` content into the corresponding OEIS submission fields.

The final version deliberately does not make a priority claim. It also explicitly clarifies that `n != T(n)` excludes fixed points of this permutation and is not a non-palindrome condition.

The cross-references are:

- A110751: digit reversal with the same prime divisors.
- A110819: non-palindromic part of A110751.
- A244514: all cyclic decimal permutations having the same prime divisors.

The definition is:

a(n) is the n-th positive integer m not ending in 0 such that m != T(m) and rad(m)=rad(T(m)), with T(d1...dk)=d1 dk d2 d{k-1} ...

The certified initial segment contains 22 terms, complete for m < 10^10 under the stated restriction.

### Keywords

Use exactly:

`base,more,nonn`

No `easy`, `nice`, `hard`, or `fini`.

## B. Superseeker check

OEIS's current FAQ recommends checking a new sequence with Superseeker before submission.

The exact lookup line for this sequence is:

`lookup 3024 6048 10143 20286 27864 117216 189216 224224 333234 352872 387585 448448 666468 3892032 3928824 137539323 247153125 321881616 869148324 1938285196 2240563518 2952612351`

OEIS currently provides Superseeker by email. The request should contain the lookup line with terms separated by spaces, not commas. The service requests at most one request per user per hour.

Record the returned response in the research archive under `logs/` if it identifies anything relevant. If it reports a sequence that is actually the same object, stop and reconcile before submitting.

## C. b-file

`b-file-final.txt` is a correctly formatted supporting b-file for terms 1..22.

Because only 22 terms are currently certified, it is optional. The main OEIS data lines already contain the same sequence. Keeping the b-file is harmless and provides a machine-readable copy.

OEIS's current b-file guidance requires:
- consecutive indices beginning at the sequence offset;
- `n a(n)` separated by one space;
- no commas;
- a final blank line.

The file follows those rules.

## D. Program files

The clean release already contains the audited search and independent verifier:

`release/code/exhaustive_search.cpp`

`release/code/verify_solutions.cpp`

`release/code/run_full_primitive_search.ps1`

The search uses the exact gcd criterion rather than separate factorization of n and T(n).

The verifier independently reconstructs T(n), checks the gcd criterion, and checks the current 22 candidates. Explicit factorization is used only as a certificate for the present examples.

## E. Paper

Use:

`outer_in_prime_support_manuscript_FINAL.tex`

and the compiled:

`outer_in_prime_support_manuscript_FINAL.pdf`

The only intentional placeholder in the manuscript is the author name. Replace `[Author]` with the human author's preferred name before any public paper submission.

The paper's mathematical scope is explicit:

`0 < n < 10^10` and `n not divisible by 10`.

It does not claim that the 22 terms are the whole infinite sequence.

## F. What is established

The final materials state only results that are supported by the archived computation or proofs:

1. The gcd/reduced-ratio criterion is an exact theorem.
2. Exactly 22 solutions occur in the stated bounded domain.
3. Exactly three occur in the ten-digit interval.
4. The three ten-digit examples have independently verified prime factorizations.
5. The repeated-block constructions prove infinite families for 224->242, 448->484, and 117->171.
6. No exact match was found in the OEIS and web-indexed searches performed through 2026-09-22.

## G. What is intentionally not claimed

Do not write:

- “first ever”
- “newly discovered”
- “no one has studied this”
- “the only such numbers”
- “the complete sequence”
- any prediction of the next term

The strongest defensible novelty wording is:

“No exact match for the present definition and displayed initial terms was found in the OEIS and web-indexed searches performed through September 22, 2026.”

## H. Final human check

OEIS currently states that the human submitter is responsible for verifying the correctness of AI-assisted material, including the name, terms, formulas, programs, and comments.

Before submitting, personally verify that the definition, 22 terms, code, and repeated-block proofs are understood. This is the final substantive human step.
