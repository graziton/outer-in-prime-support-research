# Claims Audit — Research Snapshot v1.1

| Claim | Classification | Reason |
|---|---|---|
| Definition of outer-in map \(T\) | PROVED/DEFINITION | Direct definition |
| \(\operatorname{rad}(n)=\operatorname{rad}(T(n))\iff\operatorname{rad}(ab)\mid g\) | PROVED | Elementary gcd/support argument |
| \(224Q_r\to242Q_r\) is a family | PROVED | Direct digit argument and \(77\mid Q_r\) |
| \(448Q_r\to484Q_r\) is a family | PROVED | Same argument |
| There are 36 distinct currently documented primitive examples | VERIFIED DATASET FACT | Uniqueness checked separately |
| All 36 documented examples satisfy the property | INDEPENDENTLY VERIFIED | Separate verifier returned 36/36 |
| Complete primitive list below \(10^9\) | EXHAUSTIVELY COMPUTED | Established by the original global search |
| The 36 examples form the complete sequence beyond \(10^9\) | NOT CLAIMED | Ratio-restricted searches do not prove this |
| The 12 listed ratios are the only possible ratios | NOT PROVED | They are only observed classes |
| Larger ratio-restricted negatives prove no solution exists globally | FALSE / DO NOT CLAIM | Unknown ratios remain |
| No two consecutive support-preserving orbit edges have been observed | COMPUTATIONAL OBSERVATION | Not a theorem |
| Exact problem has never been studied before | NOT ESTABLISHED | Only preliminary novelty search |
