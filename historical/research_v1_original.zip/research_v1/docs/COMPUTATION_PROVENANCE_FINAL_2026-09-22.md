# Final computation provenance

## Mathematical test

For each candidate n, construct T(n) by the fixed outer-in digit order

d_1,d_k,d_2,d_{k-1},...

Then compute

g = gcd(n,T(n)),
a = n/g,
b = T(n)/g.

Because gcd(a,b)=1,

rad(n)=rad(T(n))  <=>  rad(a*b) | g.

The exhaustive search uses this exact criterion. It does not factor n and T(n) independently.

## Search domain

The definitive completeness claim is:

0 < n < 10^10,
n mod 10 != 0.

The first 19 terms were established by exhaustive computation below 10^9. The complete interval 10^9 <= n < 10^10 was then searched by the audited ratio-independent implementation.

## Ten-digit result

Exactly three hits occur in the ten-digit interval:

1938285196 -> 1699318528, gcd 26551852, reduced ratio 73:64
2240563518 -> 2821450356, gcd 82983834, reduced ratio 27:34
2952612351 -> 2195532261, gcd 75708009, reduced ratio 39:29

## Independent verification

The independent verifier reconstructs T(n), computes the gcd and reduced pair, and checks the exact criterion. For the 22 current candidates it additionally performs explicit factorization checks. All 22 candidates passed.

The verifier's factorization routine is only a certificate for the present dataset; it is not intended as a general large-integer factoring engine.

## Reproducibility files

The clean release already contains:

- code/exhaustive_search.cpp
- code/verify_solutions.cpp
- code/run_full_primitive_search.ps1
- data/primitive_solutions_through_1e10.csv
- verification/final_22_verification_input.txt
- verification/canonical_dataset_verification.txt
- oeis/b-file.txt

The final manuscript deliberately distinguishes the historical two-stage computation from the clean release package; it does not claim that the original 19-term phase used the identical source file line-for-line.
