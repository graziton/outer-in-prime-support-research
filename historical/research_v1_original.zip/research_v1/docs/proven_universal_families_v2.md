# Proven Universal Repeated-Block Families — v2

## 1. General construction

Let \(B\) be an \(m\)-digit block and suppose

\[
T(BB)=CC
\]

for an \(m\)-digit block \(C\).

Then, for every \(r\ge1\),

\[
T(B^{2r})=C^{2r}.
\]

Write \(A=[B]\) and \(C_0=[C]\), and define

\[
Q_r=1+10^m+10^{2m}+\cdots+10^{(2r-1)m}.
\]

Then

\[
[B^{2r}]=AQ_r,\qquad [C^{2r}]=C_0Q_r.
\]

Let \(P(x)\) denote the set of distinct prime divisors of \(x\).

A universal prime-support family is obtained exactly when

\[
P(A)\triangle P(C_0)
\subseteq
P(10^m+1).
\]

Equivalently, after writing

\[
A=ag,\qquad C_0=bg,\qquad g=\gcd(A,C_0),\quad \gcd(a,b)=1,
\]

every prime divisor of \(ab\) must divide

\[
g(10^m+1).
\]

## 2. Proven family I: 224 / 242

Take

\[
B=224,\qquad C=242,\qquad m=3.
\]

Then

\[
T(224224)=242242.
\]

Also

\[
224=2^5\cdot7,\qquad 242=2\cdot11^2.
\]

Thus

\[
P(224)\triangle P(242)=\{7,11\}.
\]

Since

\[
10^3+1=1001=7\cdot11\cdot13,
\]

the universal criterion is satisfied.

Therefore, for every \(r\ge1\),

\[
\boxed{
224^{\,2r}\longrightarrow242^{\,2r}
}
\]

in block-repetition notation. Explicitly, this is

\[
\underbrace{224224\cdots224}_{2r\text{ blocks}}
\longrightarrow
\underbrace{242242\cdots242}_{2r\text{ blocks}}.
\]

The first members are

\[
224224\to242242,
\]

\[
224224224224\to242242242242,
\]

and so on.

## 3. Proven family II: 448 / 484

Take

\[
B=448,\qquad C=484,\qquad m=3.
\]

Then

\[
T(448448)=484484.
\]

Also

\[
448=2^6\cdot7,\qquad 484=2^2\cdot11^2,
\]

so again

\[
P(448)\triangle P(484)=\{7,11\}.
\]

Since

\[
7,11\mid10^3+1,
\]

the universal criterion is satisfied.

Therefore, for every \(r\ge1\),

\[
\boxed{
\underbrace{448448\cdots448}_{2r\text{ blocks}}
\longrightarrow
\underbrace{484484\cdots484}_{2r\text{ blocks}}
}.
\]

## 4. Proven family III: 117117117 / 171171171

This is a genuinely different family.

Take the 9-digit blocks

\[
B=117117117,
\qquad
C=171171171,
\qquad
m=9.
\]

Directly,

\[
T(BB)=CC.
\]

The block values factor as

\[
117117117=117(1+10^3+10^6),
\]

\[
171171171=171(1+10^3+10^6).
\]

Their reduced ratio is

\[
117117117:171171171=13:19,
\]

because

\[
\gcd(117,171)=9.
\]

The distinct-prime support difference between the two block values is

\[
P(117117117)\triangle P(171171171)=\{13,19\}.
\]

Now

\[
10^9+1
=
1000000001
=
7\cdot11\cdot13\cdot19\cdot52579.
\]

Hence

\[
13,19\mid10^9+1,
\]

so the universal criterion is satisfied.

Therefore, for every \(r\ge1\),

\[
\boxed{
\underbrace{117117117\,117117117\cdots117117117}_{2r\text{ blocks}}
\longrightarrow
\underbrace{171171171\,171171171\cdots171171171}_{2r\text{ blocks}}
}.
\]

Equivalently, the decimal digit `117` is repeated \(6r\) times on the left, and `171` is repeated \(6r\) times on the right.

The first prime-support-preserving member is therefore

\[
\boxed{
117117117117117117
\longrightarrow
171171171171171171
}.
\]

The shorter transformation

\[
117117117\longrightarrow171171171
\]

is a useful **seed relation**, but it should not itself be counted as a prime-support solution. The infinite family begins at an even number of 9-digit seed blocks.

## 5. Current finite computational classification

The program `universal_block_search_v2.cpp` exhaustively examined the structurally eligible primitive blocks through block length \(12\).

It reported 9 rows, but these represent repetitions of the following three underlying constructions:

\[
224\to242,
\]

\[
448\to484,
\]

\[
117117117\to171171171.
\]

The length-6 and length-12 rows for the first two families are longer periodic descriptions of the same constructions.

### Scope

The computation proves only the finite statement:

> Among the primitive structurally eligible blocks examined through length 12, the universal repeated-block constructions found reduce to the three constructions above.

It does **not** prove that these are the only infinite families for the original outer-in prime-support problem.

## 6. Important terminology

A short periodic representation is not automatically a universal seed.

In particular:

\[
117\to171
\]

is **not** a universal repeated-block prime-support family under the \(m=3\) criterion.

The valid universal seed used here is

\[
117117117\to171171171
\]

with \(m=9\).

This distinction should be preserved in all later data and writing.
