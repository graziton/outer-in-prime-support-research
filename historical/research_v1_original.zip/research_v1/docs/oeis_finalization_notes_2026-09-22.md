# OEIS Finalization Notes — Changes Only

Do not replace the whole release package. Apply only the following editorial changes to the existing draft.

## 1. Keep the definition explicit

Use the exact operation:

T(d_1 d_2 ... d_k) = d_1 d_k d_2 d_{k-1} d_3 d_{k-2} ...

and explicitly state that the decimal integer is written without leading zeros.

## 2. Avoid relying on “primitive” as the mathematical definition

“Primitive” is useful as an internal label for the search domain, but it can be confused with other number-theoretic uses. The actual sequence definition should simply say:

- n does not end in 0;
- n != T(n);
- rad(n) = rad(T(n)).

In the comments, “primitive (nonzero-last-digit) search” may be used as a computational description if desired.

## 3. Keep the exact gcd criterion

The statement

g = gcd(n,T(n)), n = ag, T(n) = bg, gcd(a,b)=1

and

rad(n)=rad(T(n)) iff rad(ab) | g

is one of the strongest mathematical additions to the entry. Keep it.

Also note the equivalent form

a*rad(ab) | n.

## 4. Keep the completeness statement bounded

Use:

“The 22 terms shown are complete among integers n < 10^10 satisfying the stated nonzero-last-digit restriction.”

Do not imply that these are the only terms of the infinite sequence.

## 5. Infinite families

The three proven repeated-block families are worth retaining:

- repetitions of 224 map to repetitions of 242;
- repetitions of 448 map to repetitions of 484;
- repetitions of 117 map to repetitions of 171 when the block 117 is repeated 6r times.

Keep the proof mechanism short in the OEIS entry; the full proof belongs in the manuscript.

## 6. Cross-references

Keep:

Cf. A110751, A110819.

These are the directly analogous OEIS reversal sequences.

## 7. Example selection

The most informative examples are:

- T(12345)=15243 for defining the map;
- 3024 -> 3402 for a small verified example;
- 2240563518 -> 2821450356 with gcd 82983834 and reduced ratio 27:34 for a 10-digit example.

## 8. b-file

The existing b-file is correctly indexed from 1 through 22 and contains the same ordered terms as the data field.

The current OEIS b-file rules require consecutive indices beginning at the sequence offset and use `n a(n)` with a single space and no commas. A final blank line is recommended.

## 9. Submission wording

Do not claim a proven novelty/priority result. Use wording equivalent to:

“No exact match was found in the OEIS searches performed.”

This is more defensible than “new” or “first”.

## 10. Human final review

Before actual submission, independently check:

- every displayed term;
- every displayed T(n);
- the 22-term ordering;
- the gcd/reduced-ratio formula;
- the repeated-block family proofs;
- the search interval statement.

OEIS currently emphasizes that the human submitter is responsible for correctness and understanding of AI-assisted material.
