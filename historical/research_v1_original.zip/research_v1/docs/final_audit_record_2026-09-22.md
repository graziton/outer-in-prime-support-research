# Final Audit Record — 2026-09-22

## Dataset checks

Canonical solution count: 22.

All 22 terms:
3024, 6048, 10143, 20286, 27864, 117216, 189216, 224224,
333234, 352872, 387585, 448448, 666468, 3892032, 3928824,
137539323, 247153125, 321881616, 869148324, 1938285196,
2240563518, 2952612351.

Arithmetic checks performed independently:

- T(n) was reconstructed from decimal digits for all 22 terms.
- Every n satisfies n != T(n).
- Every n is nonzero-ending.
- gcd/reduced-ratio checks passed.
- The three 10-digit pairs factor as documented in the manuscript.
- All three 10-digit pairs have identical prime supports.
- The 22-term ordering is strictly increasing.
- 19 terms are below 10^9 and 3 terms lie in [10^9,10^10).

## Proof checks

The gcd criterion was checked algebraically:

If n=ag and T(n)=bg with gcd(a,b)=1, then
rad(n)=rad(T(n)) iff rad(ab)|g.

The repeated-block argument uses
Q_r = 1 + 10^m + ... + 10^((2r-1)m)
and the identity 10^m+1 | Q_r.

The three documented infinite-family constructions are consistent with that criterion:

- 224 -> 242: required support primes 7,11 divide 10^3+1.
- 448 -> 484: required support primes 7,11 divide 10^3+1.
- 117 -> 171: using 9-digit blocks 117117117 -> 171171171, required support primes 13,19 divide 10^9+1.

## Editorial correction made

The earlier manuscript wording that suggested the nonzero-last-digit restriction was needed to prevent a leading zero was removed. The restriction is now stated simply as part of the sequence definition/search domain.

## Current claim level

The manuscript does not claim mathematical priority. It states only that no exact match was found in the OEIS/web searches performed through 2026-09-22.

## OEIS alignment

The final OEIS draft uses:

- definition in %N;
- transformation and radical definition in %C;
- exact gcd criterion in %C;
- bounded completeness statement in %C;
- infinite-family information in %C/%F;
- examples in %e;
- 22-term data in %S;
- cross-references to A110751 and A110819;
- offset 1,1;
- separate b-file retained.

The current OEIS submission page requires careful correctness checking and says a new sequence submission is unnumbered and later assigned an A-number. The current b-file guidance requires consecutive n,a(n) pairs beginning at the sequence offset, with no commas and a terminating blank line; it also recommends including the computation program when possible.
