# Research Claims Audit — v1.2

## Safe statements

### PROVED
- The definition of \(T\).
- The exact gcd/radical criterion.
- The repeated-block theorem under \(T(BB)=CC\).
- The universal-family criterion
  \[
  P(A)\triangle P(C)\subseteq P(10^m+1).
  \]
- The three explicit repeated-block families currently documented.

### EXHAUSTIVELY COMPUTED
- The primitive solutions for \(n<10^9\).
- The constrained repeated-block search through block length 12, within the stated structural search space.

### INDEPENDENTLY VERIFIED
- 39 distinct currently documented primitive examples.

### OBSERVATION
- Sparsity of support matches in the fixed-ratio searches examined.
- Different behavior among reduced-ratio classes.
- No observed nontrivial orbit with two consecutive support-preserving edges.

### NOT PROVED
- That the 39 examples form the complete primitive sequence.
- That the currently observed 12 reduced ratios are exhaustive.
- That the three repeated-block generators are the only infinite families.
- That every nontrivial orbit contains at most one support-preserving edge.
- That the exact problem has never previously appeared in the literature.

## Important correction to the v2 block-search artifact

The search criterion used by `universal_block_search_v2.cpp` is the correct criterion

\[
\operatorname{rad}(ab)\mid g(10^m+1),
\]

but its CSV column `unmatched_prime_factors` was populated incorrectly for cases where a prime in \(a\) or \(b\) was already present in \(g\).

For example, for \(224\to242\) it reported `2*7*11`, whereas the actual support symmetric difference is only

\[
\{7,11\}.
\]

Therefore the v2 CSV should be treated as an internal computational artifact, not as the final public data description.

The corrected mathematical formulation in this snapshot uses the symmetric difference of the prime supports of the two block values.
