# Final Novelty / Positioning Check — 2026-09-22

## Scope checked

The target object is the decimal transformation

T(d1 d2 ... dk) = d1 dk d2 d{k-1} d3 d{k-2} ...

together with the condition

rad(n) = rad(T(n)), n != T(n),

under the computational restriction that n does not end in 0.

The current exhaustive result is 22 such integers below 10^10.

## Search outcome

I searched the current OEIS/web-indexed material using:

- exact initial terms: 3024, 6048, 10143, 20286, 27864
- later terms including 137539323, 247153125, 321881616, 869148324
- all three 10-digit terms: 1938285196, 2240563518, 2952612351
- exact source/target pairs for the three 10-digit terms
- descriptions involving “same prime divisors”, “same set of distinct prime factors”, digit permutations, and the outer-in/first-last-second-second-last permutation

No exact sequence matching the 22-term list or the defining transformation-plus-radical condition was found in the searches performed.

This should be stated as a search result, not as a formal proof of priority: “No exact match was found in the OEIS and web searches performed through 2026-09-22.”

## Closest established OEIS relatives

### A110751

A110751 is the sequence of numbers n such that n and its digit reversal have the same prime divisors. It explicitly includes palindromes and has infinitely many non-palindromic terms. The entry gives examples such as 1089 and 9801 and notes concatenation constructions.

Source: https://oeis.org/A110751

### A110819

A110819 is the non-palindromic subsequence of A110751. Its defining operation is still full digit reversal, not the outer-in interleaving used here.

Source: https://oeis.org/A110819

These are the most important cross-references because they show that the underlying prime-support invariant under a digit operation is established, while the specific outer-in map is different.

## General digit-permutation literature

Digit-permutation arithmetic is a well-established subject. In particular, Benjamin V. Holt's work on permutiples studies integers related multiplicatively to permutations of their digits, including cyclic permutations and reversals.

- Holt, “On Permutiples Having a Fixed Set of Digits”, INTEGERS 17 (2017).
- Holt, “A Method for Finding All Permutiples with a Fixed Set of Digits from a Single Known Example” (2023 preprint).

Those works concern multiplicative relations between digit permutations. The present problem instead fixes one specific digit permutation and asks for equality of the sets of distinct prime divisors. The reduced-ratio/gcd criterion used here is therefore a different formulation.

## Status of the outer-in permutation itself

The ordering “first, last, second, second-last, ...” is a standard generic sequence-reordering operation in programming and is not claimed as a new permutation. The potentially new object is the arithmetic property obtained by combining this fixed digit map with equality of prime supports.

## Claims that are safe to make

Safe:

- “We define and study the outer-in decimal digit transformation ...”
- “We enumerate integers satisfying rad(n)=rad(T(n)) and n!=T(n), with n not ending in 0.”
- “An exhaustive computation finds exactly 22 such integers below 10^10.”
- “No exact match was found in the OEIS/web searches performed through 2026-09-22.”
- “The closest OEIS analogues located are A110751 and A110819, which use digit reversal.”
- “We give an exact gcd/reduced-ratio criterion and prove several infinite repeated-block families.”

Avoid:

- “This is the first such sequence.”
- “No one has studied this.”
- “This has never appeared before.”
- Any assertion of mathematical priority unless independently established by a literature/author-priority investigation.

## Current evidence supporting the computational claim

The final dataset has 22 entries:

3024, 6048, 10143, 20286, 27864, 117216, 189216, 224224,
333234, 352872, 387585, 448448, 666468, 3892032, 3928824,
137539323, 247153125, 321881616, 869148324, 1938285196,
2240563518, 2952612351.

The first 19 were exhausted below 10^9; the full 10-digit interval [10^9, 10^10) produced exactly three additional hits.

The three 10-digit reduced ratios are:

- 1938285196 / 1699318528 = 73 / 64
- 2240563518 / 2821450356 = 27 / 34
- 2952612351 / 2195532261 = 39 / 29

## OEIS submission guidance checked

The current OEIS contribution pages state that new sequences are submitted as unnumbered sequences and receive an A-number later. They also specify that b-files use one `n a(n)` pair per line, consecutive indices beginning at the offset, with spaces rather than commas; a final blank line is recommended. OEIS also recommends providing the program used to compute a b-file when possible.

Sources:

- https://oeis.org/Submit.html
- https://oeis.org/SubmitB.html

## Important current OEIS AI-use note

OEIS currently states that the human submitter is responsible for checking AI-assisted material and that the submitted mathematical content, formulas, programs, and comments must be understood and verified by the human author.

Source:
https://oeis.org/wiki/Use_of_AI_for_OEIS_Submissions

Therefore this archive should be treated as a research/drafting aid; before submission, the human author should personally review and rewrite the final OEIS prose and be able to explain the computation and proofs.
