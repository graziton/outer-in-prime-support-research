# Proven Universal Repeated-Block Families — v3

## General theorem

Let \(B\) be an \(m\)-digit block. Suppose that

\[
T(BB)=CC
\]

for another \(m\)-digit block \(C\).

Then, for every \(r\ge1\),

\[
T(B^{2r})=C^{2r}.
\]

Writing \(A=[B]\), \(C_0=[C]\), and

\[
Q_r=1+10^m+\cdots+10^{(2r-1)m},
\]

we have

\[
[B^{2r}]=AQ_r,\qquad [C^{2r}]=C_0Q_r.
\]

Let \(P(x)\) denote the set of distinct prime divisors of \(x\).

Then the repeated-block family preserves prime support for every \(r\ge1\) if and only if

\[
\boxed{
P(A)\triangle P(C_0)
\subseteq
P(10^m+1)
}.
\]

### Proof

The structural relation \(T(BB)=CC\), together with the positional periodicity of \(B^{2r}\), gives

\[
T(B^{2r})=C^{2r}.
\]

Thus the two integers are \(AQ_r\) and \(C_0Q_r\).

Any prime in \(P(Q_r)\) occurs on both sides. The only possible discrepancy therefore comes from a prime in the symmetric difference \(P(A)\triangle P(C_0)\).

If such a prime \(p\) divides \(10^m+1\), then

\[
10^m\equiv-1\pmod p,
\]

and hence

\[
Q_r
=
1+10^m+\cdots+10^{(2r-1)m}
\equiv
1-1+\cdots+1-1
\equiv0\pmod p.
\]

Thus \(p\) is supplied by the common repetition factor.

Conversely, if support equality holds for every \(r\), it must hold for \(r=1\), where

\[
Q_1=10^m+1.
\]

Therefore every prime in the symmetric difference must divide \(10^m+1\).

Hence the criterion is necessary and sufficient.

## Family I: 224 / 242

\[
224\to242.
\]

The unmatched primes are

\[
\{7,11\},
\]

and

\[
10^3+1=1001=7\cdot11\cdot13.
\]

Therefore, for every \(r\ge1\),

\[
\underbrace{224224\cdots224}_{2r\text{ blocks}}
\to
\underbrace{242242\cdots242}_{2r\text{ blocks}}
\]

is a primitive solution.

## Family II: 448 / 484

\[
448\to484.
\]

Again the unmatched primes are

\[
\{7,11\},
\]

and both divide \(10^3+1\).

Therefore, for every \(r\ge1\),

\[
\underbrace{448448\cdots448}_{2r\text{ blocks}}
\to
\underbrace{484484\cdots484}_{2r\text{ blocks}}
\]

is a primitive solution.

## Family III: 117117117 / 171171171

Let

\[
B=117117117,\qquad C=171171171.
\]

Then

\[
T(BB)=CC
\]

and

\[
B:C=13:19
\]

after cancellation of the common factor.

The unmatched primes are

\[
\{13,19\},
\]

while

\[
10^9+1
=
7\cdot11\cdot13\cdot19\cdot52579.
\]

Therefore, for every \(r\ge1\),

\[
\underbrace{117117117\,117117117\cdots117117117}_{2r\text{ blocks}}
\to
\underbrace{171171171\,171171171\cdots171171171}_{2r\text{ blocks}}
\]

is a primitive solution.

The first member is

\[
117117117117117117
\to
171171171171171171.
\]

Equivalently, if the smaller block `117` is repeated, the construction works whenever the number of repetitions is a positive multiple of 6.

## Finite computational search

The constrained universal-family search through block length 12 found nine output rows, but after identifying shorter periodic generators these reduce to the three constructions above.

The finite search statement is therefore:

> Among the structurally eligible primitive blocks examined through length 12, the universal repeated-block constructions found reduce to the three generators \(224\to242\), \(448\to484\), and \(117117117\to171171171\).

This does not classify all possible infinite families of the original problem.
