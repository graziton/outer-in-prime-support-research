# Research Snapshot v1 — 2026-09-22

## 1. Problem definition

For a decimal string \(d_1d_2\ldots d_k\), define

\[
T(d_1d_2\ldots d_k)
=
d_1d_kd_2d_{k-1}d_3d_{k-2}\ldots.
\]

The target property is

\[
n\ne T(n),\qquad
\operatorname{rad}(n)=\operatorname{rad}(T(n)).
\]

For this snapshot, `primitive` means that the original integer \(n\) does not end in zero.

## 2. What is established

### 2.1 Exact algebraic criterion

With

\[
g=\gcd(n,T(n)),\qquad n=ag,\qquad T(n)=bg,\qquad (a,b)=1,
\]

prime-support equality is equivalent to

\[
\operatorname{rad}(ab)\mid g.
\]

This follows because any prime dividing one of \(a,b\) cannot divide the other, since \((a,b)=1\), while all primes already present in \(g\) occur in both \(n\) and \(T(n)\).

### 2.2 Proven infinite families

For

\[
Q_r=\frac{10^{6r}-1}{999},
\]

we have

\[
T(224Q_r)=242Q_r,
\]

and

\[
T(448Q_r)=484Q_r.
\]

Since \(1000\equiv-1\pmod{77}\) and there are \(2r\) terms in the geometric sum defining \(Q_r\),

\[
77\mid Q_r.
\]

Therefore both families preserve prime support.

## 3. Current examples

There are currently 36 documented primitive examples in `data/known_primitive_examples.csv`.

All 36 were independently checked by the separate verifier program and returned `VERIFIED`.

These 36 examples should be described as **known verified examples**, not as the complete sequence.

## 4. Exhaustive computation

The primitive search below \(10^9\) found 19 solutions and is globally exhaustive in that range.

Beyond \(10^9\), additional examples were found using searches restricted to previously observed reduced ratios.

Therefore the current larger examples do not by themselves establish the exact ordering of the complete primitive sequence beyond \(10^9\).

## 5. Observed ratio classes

The current 36 examples fall into these reduced-ratio classes:

| Ratio | Current verified example count |
|---|---:|
| 8:9 | 8 |
| 7:9 | 2 |
| 9:8 | 5 |
| 8:11 | 1 |
| 112:121 | 10 |
| 33:34 | 2 |
| 13:12 | 2 |
| 27:25 | 1 |
| 32:27 | 2 |
| 2257:2187 | 1 |
| 625:643 | 1 |
| 1331:1296 | 1 |
| **Total** | **36** |

## 6. Important computational observations

The search has shown strong sparsity at larger digit lengths in several already-observed ratio classes.

For example, the fixed-ratio exhaustive searches established no ratio solutions in the following completed ranges:

- \(8:9\): 25, 26, 28, 29, 30 digits; 27 digits has one ratio solution and one support match.
- \(9:8\): 25 through 30 digits: no ratio solutions.
- \(7:9\): 25 through 30 digits: no ratio solutions.
- \(8:11\): 25 through 30 digits: no ratio solutions.
- \(33:34\): 25, 26, 28, 29 digits had no ratio solutions; 27 and 30 digits each had one ratio solution, neither a support match.
- \(13:12\): 25, 28, 29 digits had no ratio solutions; 26 had one ratio solution without support match; 27 had one genuine support match. The 30-digit search was still incomplete at the time of this snapshot.

These statements concern the fixed-ratio searches actually run and should not be generalized to the entire problem.

## 7. Current conjectures / questions

These are not theorems:

- There may be strong restrictions on which reduced ratios can occur.
- Prime-support-preserving solutions appear sparse among fixed-ratio permutiple solutions.
- In the computations performed so far, no nontrivial orbit was observed to contain two consecutive support-preserving edges.
- The mechanism producing the \(112:121\) repeated-block family may have analogues for other ratio classes.

## 8. Novelty statement

Preliminary searches did not locate an OEIS entry or paper matching the exact combination of:

1. the outer-in digit permutation \(T\), and
2. equality of the sets of distinct prime divisors of \(n\) and \(T(n)\).

This is only a preliminary novelty assessment. The established reversal problem and the general literature on digit-preserving multiplication/permutiples are closely related and must be cited in any eventual public paper or OEIS entry.

## 9. Research status

At the date of this snapshot:

**Established:**
- exact definition;
- exact gcd/radical criterion;
- a provable infinite family;
- 36 independently verified primitive examples;
- global exhaustive primitive computation below \(10^9\).

**Not established:**
- completeness of the sequence beyond \(10^9\);
- classification of all possible reduced ratios;
- classification of all infinite families;
- proof of orbit uniqueness;
- proof that the exact problem is previously unstudied.

## 10. Next research stage

The next computational target is a ratio-independent finite-state/carry search capable of finding or ruling out solutions without assuming a previously observed reduced ratio. This is intended to close the main completeness gap before an OEIS submission is prepared.
