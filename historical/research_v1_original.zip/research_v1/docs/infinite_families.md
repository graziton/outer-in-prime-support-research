# Infinite Families

## Proposition 1 — The 224/242 family

Define

\[
Q*r=\frac{10^{6r}-1}{999}
=\sum*{j=0}^{2r-1}10^{3j},
\qquad r\ge1.
\]

Then, for every \(r\ge1\),

\[
T(224Q_r)=242Q_r,
\]

and

\[
\operatorname{rad}(224Q_r)
=
\operatorname{rad}(242Q_r).
\]

Therefore every integer

\[
224Q_r
\]

is a primitive solution to the outer-in prime-support problem.

### Proof

The decimal integer \(224Q_r\) consists of \(2r\) repetitions of the block `224`:

\[
224224\ldots224.
\]

Applying the outer-in transformation alternately takes digits from the left and right ends. Because the number contains an even number of identical three-digit blocks, the resulting digits are exactly those of

\[
242242\ldots242,
\]

with \(2r\) repetitions of `242`. Hence

\[
T(224Q_r)=242Q_r.
\]

Next,

\[
1000\equiv -1\pmod{77}.
\]

Since

\[
Q_r=1+1000+1000^2+\cdots+1000^{2r-1},
\]

we obtain

\[
Q_r\equiv
1-1+1-1+\cdots+1-1
\equiv0\pmod{77}.
\]

Therefore

\[
7\mid Q_r
\qquad\text{and}\qquad
11\mid Q_r.
\]

Now

\[
224=2^5\cdot7
\]

and

\[
242=2\cdot11^2.
\]

Thus

\[
P(224Q_r)
=
\{2,7\}\cup P(Q_r),
\]

while

\[
P(242Q_r)
=
\{2,11\}\cup P(Q_r),
\]

where \(P(m)\) denotes the set of distinct prime divisors of \(m\).

Because both \(7\) and \(11\) already divide \(Q_r\),

\[
P(224Q_r)
=
P(Q_r)\cup\{2\}
=
P(242Q_r).
\]

Therefore

\[
\operatorname{rad}(224Q_r)
=
\operatorname{rad}(242Q_r).
\]

Finally, \(224Q_r\) does not end in zero, so it is primitive.

Hence the result follows. \(\square\)

---

## Proposition 2 — The 448/484 family

For every \(r\ge1\),

\[
T(448Q_r)=484Q_r,
\]

and

\[
\operatorname{rad}(448Q_r)
=
\operatorname{rad}(484Q_r).
\]

Therefore every integer

\[
448Q_r
\]

is a primitive solution.

### Proof

The decimal integer \(448Q_r\) consists of \(2r\) repetitions of `448`. The same outer-in digit-position argument gives

\[
T(448Q_r)=484Q_r.
\]

Also,

\[
448=2^6\cdot7
\]

and

\[
484=2^2\cdot11^2.
\]

Since \(77\mid Q_r\), both 7 and 11 already divide \(Q_r\). Hence both numbers have exactly the same distinct prime divisors:

\[
P(448Q_r)=P(484Q_r)=P(Q_r)\cup\{2\}.
\]

Therefore

\[
\operatorname{rad}(448Q_r)
=
\operatorname{rad}(484Q_r).
\]

Thus every \(448Q_r\) is a primitive solution. \(\square\)

---

## First members

The two families begin:

\[
224224\to242242,
\]

\[
224224224224\to242242242242,
\]

\[
224224224224224224\to242242242242242242,
\]

and so on.

Similarly,

\[
448448\to484484,
\]

\[
448448448448\to484484484484,
\]

\[
448448448448448448\to484484484484484484.
\]

The construction produces solutions at every digit length divisible by \(6\).
