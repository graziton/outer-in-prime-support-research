# Final submission checklist

## OEIS entry

Use `OEIS_SUBMISSION_FINAL_2026-09-22.txt`.

The fields included are:

- %N definition
- %C exact map, radical definition, fixed-point clarification, gcd criterion, completeness scope, reduced ratios, and proven families
- %F family formulas
- %Y cross-references A110751, A110819, A244514
- %e concrete examples
- %S/%T/%U initial 22 terms
- %K base,more,nonn
- %O 1,1

Do not add an unsupported statement that the sequence is the “first”, “new”, or “never studied before”.

## b-file

`b-file-final.txt` contains the same 22 consecutive terms, indexed from 1, with a trailing blank line.

Because only 22 terms are currently certified, the b-file is optional rather than essential. It is safe to retain it as a supporting file.

## Program

Use the existing audited release program:

`D:\OEISelease\code\exhaustive_search.cpp`

and the independent verifier:

`D:\OEISelease\codeerify_solutions.cpp`

Do not claim the verifier's trial division is a general factorization method.

## Manuscript

Use the final manuscript file supplied separately.

The only personal field intentionally left for the human author is the author name. Do not attribute authorship to an AI tool.

## Claims

The strongest verified claims are:

1. exactly 22 solutions for 0 < n < 10^10 with n not ending in 0;
2. 19 occur below 10^9 and 3 in the ten-digit interval;
3. the gcd/reduced-ratio criterion is exact;
4. three repeated-block constructions give infinite families.

The novelty statement should remain conservative: no exact match was found in the OEIS and web-indexed searches performed through 2026-09-22.

## Before clicking submit

Personally check the final text once. In particular, verify that:

- the definition matches the code;
- the 22 terms match the b-file;
- T(12345)=15243;
- T(3024)=3402;
- the three ten-digit pairs and gcds match the dataset;
- the family statements are understood and can be explained without relying on the AI-generated wording.

OEIS explicitly requires the human submitter to be responsible for correctness and understanding of AI-assisted content.
