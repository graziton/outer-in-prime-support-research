# Paper Fact Sheet — Outer-In Digit Permutation with Equal Prime Support

This file is a factual scaffold for the manuscript. It is intentionally organized as statements, proofs, and verified data rather than polished submission prose.

## 1. Definition

For a positive decimal integer

n = d_1 d_2 ... d_k,

define

T(n) = d_1 d_k d_2 d_{k-1} d_3 d_{k-2} ...

continuing until all digits are used.

Examples:

T(12345678) = 18273645
T(12345) = 15243
T(1800) = 1080

The computational sequence restricts to n not ending in 0.

The arithmetic condition is

n != T(n),
rad(n) = rad(T(n)),

where rad(n) is the product of the distinct prime divisors of n.

## 2. Exact algebraic reformulation

Let

g = gcd(n,T(n)),
n = a g,
T(n) = b g,
gcd(a,b)=1.

Then

rad(n)=rad(T(n))

if and only if

rad(ab) divides g.

Equivalently,

a*rad(ab) divides n.

Proof:

Every prime dividing a divides n. Under equality of prime supports it must divide T(n)=bg. Since gcd(a,b)=1, it cannot divide b, hence it divides g. The same argument applies to every prime dividing b.

Conversely, if rad(ab)|g, then every prime occurring in a or b also occurs in g, so n=ag and T(n)=bg have exactly the same set of prime divisors.

This criterion is the basis of the ratio-independent search.

## 3. Exhaustive computational result

For n < 10^10, under the restriction n does not end in 0, exactly 22 solutions were found:

1  3024
2  6048
3  10143
4  20286
5  27864
6  117216
7  189216
8  224224
9  333234
10 352872
11 387585
12 448448
13 666468
14 3892032
15 3928824
16 137539323
17 247153125
18 321881616
19 869148324
20 1938285196
21 2240563518
22 2952612351

The first 19 occur below 10^9. The interval 10^9 <= n < 10^10 contains exactly three.

The final 10-digit hits are:

1938285196 -> 1699318528
gcd = 26551852
reduced ratio = 73:64

2240563518 -> 2821450356
gcd = 82983834
reduced ratio = 27:34

2952612351 -> 2195532261
gcd = 75708009
reduced ratio = 39:29

## 4. Independent factorization checks

1938285196 = 2^2 * 73^2 * 90931
1699318528 = 2^8 * 73 * 90931

2240563518 = 2 * 3^5 * 17 * 139 * 1951
2821450356 = 2^2 * 3^2 * 17^2 * 139 * 1951

2952612351 = 3^3 * 13^2 * 29 * 53 * 421
2195532261 = 3^2 * 13 * 29^2 * 53 * 421

Thus all three 10-digit pairs have identical sets of distinct prime divisors.

## 5. Search methodology to describe

The definitive 10-digit search used a ratio-independent test rather than factoring n and T(n) independently.

Key points:

- T(n) is constructed directly from decimal digits.
- n divisible by 2/5 and T(n) divisible by 2/5 are compared early.
- Additional small-prime support checks are used for cheap rejection.
- Factors 3 and 9 need no separate permutation check because digit permutation preserves digit sum and therefore divisibility by 3 (and 9).
- The exact test computes g=gcd(n,T(n)) and checks rad(ab)|g.
- The audited 10-digit implementation uses uint64_t, which covers [0,10^10).

The independent verifier separately reconstructs T(n), computes gcd, reduces the ratio, and checks the exact criterion; all 22 candidates passed the verification dataset.

## 6. Repeated-block theorem

Let B be an m-digit block and suppose that applying T to BB gives CC.

For every r >= 1,

T(B^(2r)) = C^(2r).

Writing A=[B], C_0=[C], define

Q_r = 1 + 10^m + 10^(2m) + ... + 10^((2r-1)m).

Then

[B^(2r)] = A Q_r,
[C^(2r)] = C_0 Q_r.

Let g=gcd(A,C_0), A=ag, C_0=bg, gcd(a,b)=1.

The repeated-block family has equal prime support for every r provided

rad(ab) | g(10^m+1),

because

Q_r = (10^(2rm)-1)/(10^m-1)

and the factor 10^m+1 divides Q_r for the relevant parity structure.

## 7. Proven infinite families

### Family 1: 224 -> 242

For every r >= 1, repeating 224 exactly 2r times gives a term, and T maps it to the same number of repetitions of 242.

224 = 2^5 * 7
242 = 2 * 11^2

The support difference is {7,11}. Since

1000 ≡ -1 (mod 77),

we have 77 | Q_r, which supplies both missing primes.

Reduced ratio of the base blocks:

224 / 242 = 112 / 121.

### Family 2: 448 -> 484

The same construction applies:

448 = 2^6 * 7
484 = 2^2 * 11^2

Again 77 | Q_r, so every even repetition gives equal prime support.

Reduced ratio:

448 / 484 = 112 / 121.

### Family 3: 117 -> 171

For every r >= 1, repeating 117 exactly 6r times gives a term, and T maps it to repeating 171 the same number of times.

117 = 3^2 * 13
171 = 3^2 * 19

The support difference is {13,19}, and

10^9 + 1 = 7 * 11 * 13 * 19 * 52579.

Therefore the repeated-block multiplier supplies both missing primes in the required construction.

The first support-preserving member of this family is

117117117117117117 -> 171171171171171171.

## 8. Relation to existing OEIS entries

A110751:
numbers n such that n and the full digit reversal have the same prime divisors.

A110819:
non-palindromic numbers in A110751.

The present transformation is different: it alternates digits from the two ends rather than reversing all digits.

The manuscript should describe these as direct analogues, not as competing or interchangeable definitions.

## 9. Suggested manuscript structure

1. Introduction and motivation.
2. Definition of the outer-in map.
3. Prime-support formulation and the gcd/reduced-ratio theorem.
4. Search algorithm and exhaustive verification protocol.
5. Complete computational classification below 10^10.
6. Repeated-block theorem.
7. Three proven infinite families.
8. Relation to A110751/A110819 and digit-permutation literature.
9. Computational limitations and exact scope of claims.
10. OEIS submission / data availability note.
11. Conclusion.

## 10. Scope / limitations

The exhaustive classification claim is only for n < 10^10 with n not ending in 0.

The existence of infinite families means the sequence itself is not exhausted by the 22-term computational prefix.

The verifier's trial factorization is an independent check for the current 22 candidates; it should not be presented as a general-purpose factorization method for arbitrarily large integers.

Novelty should be phrased conservatively: no exact match was found in the searches performed through 2026-09-22.
