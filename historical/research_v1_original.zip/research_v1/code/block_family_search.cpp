/*
    block_family_search.cpp

    Search for infinite repeated-block families for the outer-in digit
    transformation.

    Definitions
    -----------
    For an m-digit block B, let

        N_r = B repeated 2r times.

    We look for a second m-digit block C such that, for every r >= 1,

        T(N_r) = C repeated 2r times.

    A key structural fact is:

        T(BB) = CC

    is sufficient to force

        T(B^(2r)) = C^(2r)

    for every r >= 1.

    Reason:
    During the outer-in transformation of B^(2r), the digit-pair pattern
    repeats with period m in the block-index k. Thus the complete output
    has period 2m. If the first 2m digits are already CC (period m),
    that period collapses to m for every larger even repetition count.

    Once such a block pair B -> C is found, write A and C for their
    integer values and

        Q_r = 1 + 10^m + 10^(2m) + ... + 10^((2r-1)m).

    Then

        N_r = A Q_r,
        T(N_r) = C Q_r.

    We search for families where prime-support equality holds for EVERY
    r >= 1.

    Exact support criterion
    -----------------------
    Let P(x) be the set of distinct prime divisors of x.

    Since Q_r is always odd, A and C must have the same divisibility
    by 2.

    For an odd prime p, p divides every Q_r exactly when

        10^m == -1 (mod p).

    Therefore a block pair B -> C gives a universal prime-support family
    iff:

      1. A and C have the same divisibility by 2; and
      2. every prime in P(A) XOR P(C) divides 10^m + 1.

    This program searches primitive blocks (last digit != 0) of lengths
    1..MAX_LEN. MAX_LEN is configurable from the command line, with
    default 6.

    The program reports only UNIVERSAL families. It deliberately does not
    enumerate the much larger class of "periodic" families where support
    equality holds only for selected repetition counts r.

    Output:
        block_family_results.csv
*/

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using std::string;
using std::vector;

static vector<u64> distinct_prime_factors(u64 x) {
    vector<u64> factors;

    if (x <= 1) return factors;

    if (x % 2 == 0) {
        factors.push_back(2);
        while (x % 2 == 0) x /= 2;
    }

    for (u64 p = 3; p <= x / p; p += 2) {
        if (x % p == 0) {
            factors.push_back(p);
            while (x % p == 0) x /= p;
        }
    }

    if (x > 1) factors.push_back(x);
    return factors;
}

static bool contains(const vector<u64>& v, u64 x) {
    return std::binary_search(v.begin(), v.end(), x);
}

static string factor_list(const vector<u64>& v) {
    if (v.empty()) return "";

    std::ostringstream out;
    for (size_t i = 0; i < v.size(); ++i) {
        if (i) out << '*';
        out << v[i];
    }
    return out.str();
}

static string outer_in(const string& s) {
    string t;
    t.reserve(s.size());

    size_t left = 0;
    size_t right = s.size() - 1;

    while (left <= right) {
        t.push_back(s[left]);

        if (left == right) break;

        t.push_back(s[right]);

        ++left;
        --right;
    }

    return t;
}

static bool same_two_support(const vector<u64>& a, const vector<u64>& b) {
    return contains(a, 2) == contains(b, 2);
}

int main(int argc, char** argv) {
    const int max_len = (argc >= 2) ? std::stoi(argv[1]) : 6;

    if (max_len < 1 || max_len > 6) {
        std::cerr << "ERROR: max block length must be between 1 and 6.\n";
        return 1;
    }

    std::ofstream csv("block_family_results.csv");
    if (!csv) {
        std::cerr << "ERROR: could not create block_family_results.csv\n";
        return 1;
    }

    csv << "length,block,transformed_block,"
            "base_support_match,"
            "unmatched_prime_factors,"
            "10^m_plus_1,"
            "family_type,"
            "two_blocks,"
            "transformed_two_blocks,"
            "four_blocks,"
            "transformed_four_blocks\n";

    std::cout << "============================================\n";
    std::cout << "Outer-in universal repeated-block search\n";
    std::cout << "Block lengths: 1.." << max_len << "\n";
    std::cout << "Primitive block: last digit != 0\n";
    std::cout << "Structural requirement: T(BB) = CC\n";
    std::cout << "Universal support: valid for every r >= 1\n";
    std::cout << "============================================\n\n";

    size_t blocks_tested = 0;
    size_t structurally_repeating = 0;
    size_t universal_count = 0;
    size_t already_support_preserving = 0;
    size_t new_universal_count = 0;

    for (int m = 1; m <= max_len; ++m) {
        u64 ten_pow_m = 1;
        for (int i = 0; i < m; ++i) ten_pow_m *= 10;

        const u64 plus_one = ten_pow_m + 1;
        const vector<u64> factors_plus_one =
            distinct_prime_factors(plus_one);

        const u64 first_value = ten_pow_m / 10;
        const u64 last_value = ten_pow_m - 1;

        size_t length_structural = 0;
        size_t length_universal = 0;

        for (u64 value = (m == 1 ? 1 : first_value);
             value <= last_value;
             ++value) {

            const string block = std::to_string(value);

            if (static_cast<int>(block.size()) != m) continue;
            if (block.back() == '0') continue;

            ++blocks_tested;

            const string doubled = block + block;
            const string transformed_doubled = outer_in(doubled);

            // T(BB) must be two identical copies of an m-digit block C.
            const string C = transformed_doubled.substr(0, m);

            if (transformed_doubled.substr(m, m) != C) {
                continue;
            }

            ++structurally_repeating;
            ++length_structural;

            if (C == block) continue;

            const u64 A = value;
            const u64 C_value = std::stoull(C);

            // Sanity check the structural relation.
            const string expected_two_blocks = C + C;
            if (transformed_doubled != expected_two_blocks) {
                std::cerr << "INTERNAL ERROR: T(BB) != CC for "
                          << block << '\n';
                return 2;
            }

            // Check the four-block case as an independent sanity test.
            const string four_blocks = block + block + block + block;
            const string transformed_four_blocks = outer_in(four_blocks);
            const string expected_four_blocks = C + C + C + C;

            if (transformed_four_blocks != expected_four_blocks) {
                std::cerr << "INTERNAL ERROR: T(BBBB) != CCCC for "
                          << block << '\n';
                return 3;
            }

            const vector<u64> support_A =
                distinct_prime_factors(A);
            const vector<u64> support_C =
                distinct_prime_factors(C_value);

            const bool base_match =
                (support_A == support_C);

            if (base_match) {
                ++already_support_preserving;
            }

            // Q_r is always odd, so an unmatched factor 2 can never be
            // supplied by the repeated-block multiplier.
            if (!same_two_support(support_A, support_C)) {
                continue;
            }

            vector<u64> unmatched;

            for (u64 p : support_A) {
                if (!contains(support_C, p)) {
                    unmatched.push_back(p);
                }
            }

            for (u64 p : support_C) {
                if (!contains(support_A, p)) {
                    unmatched.push_back(p);
                }
            }

            std::sort(unmatched.begin(), unmatched.end());
            unmatched.erase(
                std::unique(unmatched.begin(), unmatched.end()),
                unmatched.end()
            );

            bool universal = true;

            for (u64 p : unmatched) {
                if (p == 2 || !contains(factors_plus_one, p)) {
                    universal = false;
                    break;
                }
            }

            if (!universal) continue;

            ++universal_count;
            ++length_universal;

            if (!base_match) {
                ++new_universal_count;
            }

            const string family_type =
                base_match
                    ? "BASE_ALREADY_MATCHES"
                    : "NEW_VIA_REPETITION_FACTOR";

            csv << m << ','
                << block << ','
                << C << ','
                << (base_match ? "YES" : "NO") << ','
                << '"' << factor_list(unmatched) << '"' << ','
                << plus_one << ','
                << family_type << ','
                << doubled << ','
                << expected_two_blocks << ','
                << four_blocks << ','
                << expected_four_blocks
                << '\n';
        }

        std::cout
            << "m=" << m
            << "   structural families=" << length_structural
            << "   universal support families=" << length_universal
            << "   factors(10^m+1)="
            << factor_list(factors_plus_one)
            << '\n';
    }

    std::cout << "\n============================================\n";
    std::cout << "Blocks tested:                    "
              << blocks_tested << '\n';
    std::cout << "Structurally repeating B -> C:    "
              << structurally_repeating << '\n';
    std::cout << "Universal support families:       "
              << universal_count << '\n';
    std::cout << "Already support-preserving blocks: "
              << already_support_preserving << '\n';
    std::cout << "New universal via Q_r:            "
              << new_universal_count << '\n';
    std::cout << "CSV: block_family_results.csv\n";

    return 0;
}
