/*
    exact_lift_classifier.cpp

    Exact classification of repeated-block "lifts" for short base blocks.

    PURPOSE
    -------
    The exploratory lift search tested multipliers s=1..200 one by one.
    That creates huge output and has an arbitrary cutoff.

    This program replaces that bounded search with an exact number-theoretic
    test.

    Let B be an m-digit primitive block and C=T(B), with T(BB)=CC.
    Let A=[B], C0=[C], and let D be the symmetric difference of their
    distinct prime supports.

    For a lift multiplier s, prime-support equality for the resulting
    repeated-block family is equivalent to

        10^(m*s) == -1 (mod p)

    for every p in D.

    For p != 2,5, define h_p = ord_p(10^m).

    Then a solution for p exists iff h_p is even, and the condition is

        s == h_p/2 (mod h_p).

    Put q_p=h_p/2. Simultaneously, these congruences have a solution iff
    all q_p have the same 2-adic valuation. In that case the smallest
    positive solution is exactly

        s_min = lcm(q_p).

    This gives an EXACT minimum lift, with no search cutoff.

    For base blocks of lengths 1..6, the base values are at most 999999,
    so trial division and elementary multiplicative-order computation are
    sufficient and make the full classification fast.

    The program searches every structurally eligible primitive block for
    lengths 1..MAX_LEN.

    OUTPUT
    ------
    exact_lift_classification.csv
*/

#include <boost/multiprecision/cpp_int.hpp>

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using boost::multiprecision::cpp_int;
using std::string;
using std::vector;

/* ---------------- basic arithmetic ---------------- */

static u64 gcd64(u64 a, u64 b) {
    return std::gcd(a, b);
}

static int v2(u64 x) {
    int c = 0;
    while ((x & 1ULL) == 0ULL) {
        x >>= 1;
        ++c;
    }
    return c;
}

static u64 mul_mod(u64 a, u64 b, u64 mod) {
    return static_cast<u64>(
        (static_cast<unsigned __int128>(a) * b) % mod
    );
}

static u64 pow_mod(u64 a, u64 e, u64 mod) {
    u64 r = 1 % mod;

    while (e) {
        if (e & 1ULL)
            r = mul_mod(r, a, mod);

        a = mul_mod(a, a, mod);
        e >>= 1;
    }

    return r;
}

static cpp_int gcd_big(cpp_int a, cpp_int b) {
    while (b != 0) {
        cpp_int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

static cpp_int lcm_big(cpp_int a, u64 b) {
    if (a == 0 || b == 0)
        return 0;

    cpp_int bb = b;
    return (a / gcd_big(a, bb)) * bb;
}

static string big_to_string(const cpp_int& x) {
    return x.convert_to<string>();
}

/* ---------------- factorization ---------------- */

static vector<u64> prime_factors_distinct(u64 x) {
    vector<u64> f;

    if (x <= 1)
        return f;

    if (x % 2 == 0) {
        f.push_back(2);

        while (x % 2 == 0)
            x /= 2;
    }

    for (u64 p = 3; p <= x / p; p += 2) {
        if (x % p == 0) {
            f.push_back(p);

            while (x % p == 0)
                x /= p;
        }
    }

    if (x > 1)
        f.push_back(x);

    return f;
}

/*
    Multiplicative order of x modulo prime p.

    Requires gcd(x,p)=1.
*/
static u64 multiplicative_order_prime(
    u64 x,
    u64 p
) {
    u64 order = p - 1;

    const vector<u64> factors =
        prime_factors_distinct(order);

    for (u64 q : factors) {
        while (order % q == 0 &&
               pow_mod(
                   x % p,
                   order / q,
                   p
               ) == 1) {

            order /= q;
        }
    }

    return order;
}

/* ---------------- transformation ---------------- */

static string outer_in(const string& s) {
    string t;
    t.reserve(s.size());

    size_t l = 0;
    size_t r = s.size() - 1;

    while (l <= r) {
        t.push_back(s[l]);

        if (l == r)
            break;

        t.push_back(s[r]);

        ++l;
        --r;
    }

    return t;
}

/* ---------------- structural classes ---------------- */

struct DSU {
    vector<int> parent;
    vector<int> size;

    explicit DSU(int n)
        : parent(n), size(n, 1) {

        for (int i = 0; i < n; ++i)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] == x)
            return x;

        return parent[x] = find(parent[x]);
    }

    void unite(int a, int b) {
        a = find(a);
        b = find(b);

        if (a == b)
            return;

        if (size[a] < size[b])
            std::swap(a, b);

        parent[b] = a;
        size[a] += size[b];
    }
};

static vector<vector<int>> build_classes(int m) {
    DSU dsu(m);

    auto selected_position = [m](int j) -> int {
        if ((j & 1) == 0)
            return (j / 2) % m;

        const int i = (j - 1) / 2;
        return (m - 1 - (i % m) + m) % m;
    };

    for (int j = m; j < 2 * m; ++j) {
        dsu.unite(
            selected_position(j),
            selected_position(j - m)
        );
    }

    vector<int> root_to_class(m, -1);
    vector<vector<int>> classes;

    for (int pos = 0; pos < m; ++pos) {
        const int root = dsu.find(pos);

        if (root_to_class[root] == -1) {
            root_to_class[root] =
                static_cast<int>(classes.size());

            classes.push_back({});
        }

        classes[root_to_class[root]].push_back(pos);
    }

    return classes;
}

/* ---------------- decimal helpers ---------------- */

static u64 digits_to_value(
    const vector<int>& digits
) {
    u64 x = 0;

    for (int d : digits)
        x = x * 10ULL + static_cast<u64>(d);

    return x;
}

static string digits_to_string(
    const vector<int>& digits
) {
    string s;
    s.reserve(digits.size());

    for (int d : digits)
        s.push_back(
            static_cast<char>('0' + d)
        );

    return s;
}

static vector<u64> support_difference(
    const vector<u64>& a,
    const vector<u64>& b
) {
    vector<u64> d;

    for (u64 p : a)
        if (!std::binary_search(
                b.begin(), b.end(), p))
            d.push_back(p);

    for (u64 p : b)
        if (!std::binary_search(
                a.begin(), a.end(), p))
            d.push_back(p);

    std::sort(d.begin(), d.end());
    d.erase(
        std::unique(d.begin(), d.end()),
        d.end()
    );

    return d;
}

static string join(const vector<u64>& v) {
    if (v.empty())
        return "";

    std::ostringstream out;

    for (size_t i = 0; i < v.size(); ++i) {
        if (i)
            out << '*';

        out << v[i];
    }

    return out.str();
}

/* ---------------- exact lift classification ---------------- */

struct LiftResult {
    bool exists = false;
    cpp_int minimum = 0;
    vector<u64> q_values;
    string reason;
};

static LiftResult exact_minimum_lift(
    int m,
    const vector<u64>& diff
) {
    LiftResult result;

    if (diff.empty()) {
        result.exists = true;
        result.minimum = 1;
        result.reason = "BASE_SUPPORT_ALREADY_MATCHES";
        return result;
    }

    cpp_int L = 1;

    int required_v2 = -1;

    for (u64 p : diff) {
        if (p == 2) {
            result.reason =
                "IMPOSSIBLE_UNMATCHED_FACTOR_2";
            return result;
        }

        if (p == 5) {
            result.reason =
                "IMPOSSIBLE_UNMATCHED_FACTOR_5";
            return result;
        }

        // x = 10^m mod p must be invertible.
        const u64 x =
            pow_mod(
                10 % p,
                static_cast<u64>(m),
                p
            );

        const u64 h =
            multiplicative_order_prime(
                x,
                p
            );

        if (h & 1ULL) {
            result.reason =
                "IMPOSSIBLE_ODD_MULTIPLICATIVE_ORDER";
            return result;
        }

        const u64 q = h / 2;
        result.q_values.push_back(q);

        const int q_v2 = v2(q);

        if (required_v2 == -1)
            required_v2 = q_v2;
        else if (required_v2 != q_v2) {
            result.reason =
                "IMPOSSIBLE_INCOMPATIBLE_2_ADIC_CLASSES";
            return result;
        }

        L = lcm_big(L, q);
    }

    result.exists = true;
    result.minimum = L;
    result.reason = "EXACT_MINIMUM_LIFT";

    return result;
}

/* ---------------- main ---------------- */

int main(int argc, char** argv) {
    const int max_len =
        (argc >= 2) ? std::stoi(argv[1]) : 6;

    if (max_len < 1 || max_len > 6) {
        std::cerr
            << "ERROR: max length must be 1..6 for this exact short-block "
               "classifier.\n";
        return 1;
    }

    std::ofstream csv(
        "exact_lift_classification.csv"
    );

    if (!csv) {
        std::cerr
            << "ERROR: cannot create exact_lift_classification.csv\n";
        return 1;
    }

    csv
        << "length,"
           "block,"
           "transformed,"
           "structural,"
           "support_difference,"
           "base_period,"
           "exists,"
           "minimum_lift,"
           "first_solution_length,"
           "q_values,"
           "reason\n";

    size_t structural_candidates = 0;
    size_t possible_families = 0;
    size_t impossible_candidates = 0;

    std::cout
        << "============================================\n"
        << "Exact repeated-block lift classifier\n"
        << "No arbitrary lift cutoff\n"
        << "Block lengths: 1.." << max_len << '\n'
        << "============================================\n\n";

    for (int m = 1; m <= max_len; ++m) {
        const auto classes = build_classes(m);

        int first_class = -1;
        int last_class = -1;

        for (int c = 0;
             c < static_cast<int>(classes.size());
             ++c) {

            for (int pos : classes[c]) {
                if (pos == 0)
                    first_class = c;

                if (pos == m - 1)
                    last_class = c;
            }
        }

        vector<int> class_digit(
            classes.size(), 0
        );

        vector<int> digits(
            m, 0
        );

        size_t local_candidates = 0;
        size_t local_families = 0;

        std::function<void(int)> dfs =
            [&](int ci) {

                if (ci ==
                    static_cast<int>(classes.size())) {

                    for (int c = 0;
                         c < static_cast<int>(classes.size());
                         ++c) {

                        for (int pos : classes[c])
                            digits[pos] =
                                class_digit[c];
                    }

                    if (digits[0] == 0 ||
                        digits[m - 1] == 0)
                        return;

                    const string B =
                        digits_to_string(digits);

                    const string C =
                        outer_in(B);

                    if (B == C)
                        return;

                    const string BB = B + B;

                    if (outer_in(BB) != C + C) {
                        std::cerr
                            << "INTERNAL ERROR: structural check failed for "
                            << B << '\n';
                        std::exit(2);
                    }

                    ++structural_candidates;
                    ++local_candidates;

                    const u64 A =
                        digits_to_value(digits);

                    const u64 C0 =
                        digits_to_value(
                            vector<int>(
                                C.begin(),
                                C.end()
                            )
                        );

                    // The vector conversion above is safe because C contains
                    // only decimal digits.
                    (void)C0;

                    const u64 C_value =
                        [&]() -> u64 {
                            u64 x = 0;
                            for (char ch : C)
                                x = x * 10ULL +
                                    static_cast<u64>(ch - '0');
                            return x;
                        }();

                    const vector<u64> pA =
                        prime_factors_distinct(A);

                    const vector<u64> pC =
                        prime_factors_distinct(
                            C_value
                        );

                    const vector<u64> diff =
                        support_difference(
                            pA, pC
                        );

                    LiftResult lift =
                        exact_minimum_lift(
                            m, diff
                        );

                    if (lift.exists) {
                        ++possible_families;
                        ++local_families;
                    } else {
                        ++impossible_candidates;
                    }

                    const string minimum_lift =
                        lift.exists
                            ? big_to_string(
                                  lift.minimum)
                            : "";

                    const cpp_int first_length_big =
                        lift.exists
                            ? cpp_int(2) *
                              cpp_int(m) *
                              lift.minimum
                            : 0;

                    csv
                        << m << ','
                        << B << ','
                        << C << ','
                        << "YES" << ','
                        << '"' << join(diff) << '"' << ','
                        << "N/A" << ','
                        << (lift.exists ? "YES" : "NO") << ','
                        << minimum_lift << ','
                        << (lift.exists
                                ? big_to_string(first_length_big)
                                : "")
                        << ','
                        << '"' << join(lift.q_values) << '"' << ','
                        << lift.reason
                        << '\n';

                    if (lift.exists) {
                        std::cout
                            << "FAMILY  "
                            << B
                            << " -> "
                            << C
                            << "  min_lift="
                            << minimum_lift
                            << "  first_solution_length="
                            << big_to_string(
                                   first_length_big)
                            << "  support_diff={"
                            << join(diff)
                            << "}\n";
                    }

                    return;
                }

                const bool endpoint =
                    (ci == first_class ||
                     ci == last_class);

                const int lo =
                    endpoint ? 1 : 0;

                for (int d = lo;
                     d <= 9;
                     ++d) {

                    class_digit[ci] = d;
                    dfs(ci + 1);
                }
            };

        dfs(0);

        std::cout
            << "m=" << m
            << "  classes="
            << classes.size()
            << "  structural_candidates="
            << local_candidates
            << "  possible_lifts="
            << local_families
            << '\n';
    }

    std::cout
        << "\n============================================\n"
        << "Structural candidates: "
        << structural_candidates << '\n'
        << "Candidates with a universal lift: "
        << possible_families << '\n'
        << "Candidates with no universal lift: "
        << impossible_candidates << '\n'
        << "CSV: exact_lift_classification.csv\n"
        << "============================================\n";

    return 0;
}
