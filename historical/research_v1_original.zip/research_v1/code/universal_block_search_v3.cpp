/*
    universal_block_search_v3.cpp

    Clean repeated-block family search.

    For an m-digit block B, let A be its integer value.  We require

        T(BB) = CC

    for some m-digit block C.  Then, for every r >= 1,

        T(B^(2r)) = C^(2r).

    Let C0 be the integer value of C and

        Q_r = 1 + 10^m + ... + 10^((2r-1)m).

    Then

        value(B^(2r)) = A Q_r
        value(C^(2r)) = C0 Q_r.

    A universal prime-support family (valid for every r >= 1) is
    characterized by

        P(A) XOR P(C0) subset P(10^m + 1),

    equivalently, with g = gcd(A,C0), A=ag, C0=bg, gcd(a,b)=1,

        rad(a*b) divides g*(10^m+1).

    Instead of factoring a and b, this program tests the equivalent
    condition directly:

        gcd(a, g*(10^m+1)) = a
        gcd(b, g*(10^m+1)) = b.

    The multiplication g*(10^m+1) is kept in unsigned __int128.

    This version:
      * searches a requested inclusive block-length range;
      * constructs only structurally eligible blocks;
      * uses the correct universal criterion;
      * reports the actual support symmetric difference using
        factorization only for the comparatively small reported seeds;
      * independently checks T(BB)=CC and T(BBBB)=CCCC for every family.

    Usage:
        universal_block_search_v3.exe 13 14

    Default:
        universal_block_search_v3.exe 1 12
*/

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using u128 = unsigned __int128;
using std::string;
using std::vector;

/* ---------------- basic helpers ---------------- */

static string outer_in(const string& s) {
    string t;
    t.reserve(s.size());

    size_t l = 0;
    size_t r = s.size() - 1;

    while (l <= r) {
        t.push_back(s[l]);
        if (l == r) break;
        t.push_back(s[r]);
        ++l;
        --r;
    }

    return t;
}

static u64 digits_to_value(const string& s) {
    u64 x = 0;
    for (char c : s)
        x = x * 10 + static_cast<u64>(c - '0');
    return x;
}

static u64 gcd64(u64 a, u64 b) {
    while (b) {
        u64 t = a % b;
        a = b;
        b = t;
    }
    return a;
}

static u128 gcd128(u128 a, u128 b) {
    while (b) {
        u128 t = a % b;
        a = b;
        b = t;
    }
    return a;
}

static string to_string_u128(u128 x) {
    if (x == 0) return "0";

    string s;

    while (x > 0) {
        int d = static_cast<int>(x % 10);
        s.push_back(static_cast<char>('0' + d));
        x /= 10;
    }

    std::reverse(s.begin(), s.end());
    return s;
}

/* ---------------- simple factorization for reported seeds only ---------------- */

static vector<u64> distinct_prime_factors(u64 x) {
    vector<u64> f;

    if (x <= 1) return f;

    if (x % 2 == 0) {
        f.push_back(2);
        while (x % 2 == 0) x /= 2;
    }

    for (u64 p = 3; p <= x / p; p += 2) {
        if (x % p == 0) {
            f.push_back(p);
            while (x % p == 0) x /= p;
        }
    }

    if (x > 1) f.push_back(x);

    return f;
}

static bool contains(const vector<u64>& v, u64 x) {
    return std::binary_search(v.begin(), v.end(), x);
}

static string join_factors(const vector<u64>& f) {
    if (f.empty()) return "";

    std::ostringstream out;

    for (size_t i = 0; i < f.size(); ++i) {
        if (i) out << '*';
        out << f[i];
    }

    return out.str();
}

static vector<u64> symmetric_difference(
    const vector<u64>& a,
    const vector<u64>& b
) {
    vector<u64> out;

    for (u64 p : a)
        if (!contains(b, p))
            out.push_back(p);

    for (u64 p : b)
        if (!contains(a, p))
            out.push_back(p);

    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());

    return out;
}

/* ---------------- structural classes ---------------- */

struct DSU {
    vector<int> parent;
    vector<int> size;

    explicit DSU(int n)
        : parent(n), size(n, 1) {
        for (int i = 0; i < n; ++i)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] == x) return x;
        return parent[x] = find(parent[x]);
    }

    void unite(int a, int b) {
        a = find(a);
        b = find(b);

        if (a == b) return;

        if (size[a] < size[b])
            std::swap(a, b);

        parent[b] = a;
        size[a] += size[b];
    }
};

static vector<vector<int>> build_classes(int m) {
    DSU dsu(m);

    auto selected_position = [m](int j) -> int {
        if ((j & 1) == 0)
            return (j / 2) % m;

        const int i = (j - 1) / 2;
        return (m - 1 - i % m + m) % m;
    };

    // T(BB) = CC means output[j] = output[j-m].
    for (int j = m; j < 2 * m; ++j) {
        dsu.unite(
            selected_position(j),
            selected_position(j - m)
        );
    }

    vector<int> root_to_class(m, -1);
    vector<vector<int>> classes;

    for (int pos = 0; pos < m; ++pos) {
        const int root = dsu.find(pos);

        if (root_to_class[root] == -1) {
            root_to_class[root] =
                static_cast<int>(classes.size());
            classes.push_back({});
        }

        classes[root_to_class[root]].push_back(pos);
    }

    return classes;
}

/* ---------------- universal family test ---------------- */

static bool universal_support(
    u64 A,
    u64 C,
    u64 modulus
) {
    const u64 g = gcd64(A, C);

    const u64 a = A / g;
    const u64 b = C / g;

    const u128 allowed =
        static_cast<u128>(g) *
        static_cast<u128>(modulus);

    return
        gcd128(static_cast<u128>(a), allowed) ==
            static_cast<u128>(a)
        &&
        gcd128(static_cast<u128>(b), allowed) ==
            static_cast<u128>(b);
}

/* ---------------- exact power-of-10 handling ---------------- */

static u64 pow10_u64(int m) {
    u64 x = 1;

    for (int i = 0; i < m; ++i)
        x *= 10;

    return x;
}

/* ---------------- main ---------------- */

int main(int argc, char** argv) {
    const int start_len =
        (argc >= 2) ? std::stoi(argv[1]) : 1;

    const int end_len =
        (argc >= 3) ? std::stoi(argv[2]) : 12;

    if (start_len < 1 ||
        end_len < start_len ||
        end_len > 18) {

        std::cerr
            << "ERROR: use 1 <= start <= end <= 18\n";
        return 1;
    }

    std::ofstream csv("universal_block_families_v3.csv");

    if (!csv) {
        std::cerr
            << "ERROR: cannot create CSV output.\n";
        return 1;
    }

    csv
        << "length,block,transformed_block,"
           "classes,minimal_period,"
           "support_symmetric_difference,"
           "10^m_plus_1,first_family_member,"
           "first_transformed_member,status\n";

    size_t structural_candidates = 0;
    size_t family_rows = 0;

    std::cout
        << "============================================\n"
        << "Universal repeated-block family search v3\n"
        << "Correct support criterion\n"
        << "Length range: " << start_len
        << ".." << end_len << '\n'
        << "Primitive block: first and last digit nonzero\n"
        << "============================================\n\n";

    for (int m = start_len; m <= end_len; ++m) {
        const u64 ten_m = pow10_u64(m);
        const u64 modulus = ten_m + 1;

        const vector<vector<int>> classes =
            build_classes(m);

        int first_class = -1;
        int last_class = -1;

        for (int c = 0;
             c < static_cast<int>(classes.size());
             ++c) {

            for (int pos : classes[c]) {
                if (pos == 0)
                    first_class = c;

                if (pos == m - 1)
                    last_class = c;
            }
        }

        vector<int> class_digit(classes.size(), 0);
        vector<int> digits(m, 0);

        size_t length_candidates = 0;
        size_t length_families = 0;

        std::function<void(int)> dfs =
            [&](int class_index) {

                if (class_index ==
                    static_cast<int>(classes.size())) {

                    ++structural_candidates;
                    ++length_candidates;

                    // Expand class assignment into digit string.
                    for (int c = 0;
                         c < static_cast<int>(classes.size());
                         ++c) {

                        for (int pos : classes[c])
                            digits[pos] = class_digit[c];
                    }

                    // Primitive decimal block.
                    if (digits[0] == 0 ||
                        digits[m - 1] == 0)
                        return;

                    string B;
                    B.reserve(m);

                    for (int d : digits)
                        B.push_back(
                            static_cast<char>('0' + d)
                        );

                    const string C = outer_in(B);

                    if (B == C)
                        return;

                    // Structural verification.
                    const string BB = B + B;
                    const string CC = C + C;

                    if (outer_in(BB) != CC) {
                        std::cerr
                            << "INTERNAL ERROR: T(BB)!=CC for "
                            << B << '\n';
                        std::exit(2);
                    }

                    const string BBBB = BB + BB;
                    const string CCCC = CC + CC;

                    if (outer_in(BBBB) != CCCC) {
                        std::cerr
                            << "INTERNAL ERROR: T(BBBB)!=CCCC for "
                            << B << '\n';
                        std::exit(3);
                    }

                    const u64 A = digits_to_value(B);
                    const u64 C0 = digits_to_value(C);

                    if (!universal_support(
                            A, C0, modulus)) {
                        return;
                    }

                    ++family_rows;
                    ++length_families;

                    const u64 period_g =
                        [&]() {
                            // Minimal decimal period of the block.
                            for (int p = 1; p <= m; ++p) {
                                if (m % p != 0)
                                    continue;

                                bool ok = true;

                                for (int i = p; i < m; ++i) {
                                    if (B[i] != B[i % p]) {
                                        ok = false;
                                        break;
                                    }
                                }

                                if (ok)
                                    return static_cast<u64>(p);
                            }

                            return static_cast<u64>(m);
                        }();

                    vector<u64> fA =
                        distinct_prime_factors(A);
                    vector<u64> fC =
                        distinct_prime_factors(C0);

                    vector<u64> diff =
                        symmetric_difference(fA, fC);

                    // First family member uses two copies.
                    const string first_n = BB;
                    const string first_t = CC;

                    csv
                        << m << ','
                        << B << ','
                        << C << ','
                        << classes.size() << ','
                        << period_g << ','
                        << '"' << join_factors(diff) << '"' << ','
                        << modulus << ','
                        << first_n << ','
                        << first_t << ','
                        << "VERIFIED_STRUCTURAL_AND_UNIVERSAL"
                        << '\n';

                    std::cout
                        << "FAMILY  "
                        << B
                        << " -> "
                        << C
                        << "  classes="
                        << classes.size()
                        << "  period="
                        << period_g
                        << "  support_diff={"
                        << join_factors(diff)
                        << "}"
                        << "  M="
                        << modulus
                        << '\n';

                    return;
                }

                const bool endpoint_class =
                    class_index == first_class ||
                    class_index == last_class;

                const int lo =
                    endpoint_class ? 1 : 0;

                for (int d = lo; d <= 9; ++d) {
                    class_digit[class_index] = d;
                    dfs(class_index + 1);
                }
            };

        dfs(0);

        std::cout
            << "m=" << m
            << "  classes=" << classes.size()
            << "  structural_candidates="
            << length_candidates
            << "  universal_family_rows="
            << length_families
            << '\n';
    }

    std::cout
        << "\n============================================\n"
        << "Structural candidates tested: "
        << structural_candidates << '\n'
        << "Universal family rows:        "
        << family_rows << '\n'
        << "CSV: universal_block_families_v3.csv\n";

    return 0;
}
