/*
    universal_block_search.cpp

    Research tool for repeated-block infinite families.

    Problem
    -------
    Let T be the outer-in digit transformation:
        d0 d1 ... d(m-1) -> d0 d(m-1) d1 d(m-2) ...

    Let B be an m-digit primitive block (first and last digits nonzero).

    We look for universal repeated-block families.  If B is repeated 2r
    times, write B^(2r).  A block B is structurally eligible when

        T(BB) = CC

    for some m-digit block C.  For such a block, the repeated-block
    construction gives

        T(B^(2r)) = C^(2r)

    for every r >= 1.

    Write A = value(B), C0 = value(C), and

        Q_r = 1 + 10^m + ... + 10^((2r-1)m).

    Then

        value(B^(2r)) = A Q_r
        value(C^(2r)) = C0 Q_r.

    Let g = gcd(A,C0), A = a g, C0 = b g, gcd(a,b)=1.

    The family preserves prime support for EVERY r >= 1 iff every prime
    dividing a*b divides 10^m + 1.

    Equivalently, after stripping from a and b every distinct prime
    factor of 10^m+1, both a and b must reduce to 1.

    This program:
      * derives the exact structural digit constraints for T(BB)=CC;
      * enumerates only blocks satisfying those constraints;
      * tests the exact universal prime-support criterion;
      * independently verifies every reported family seed for r=1 and r=2;
      * reports the minimal period of each seed, so repeated descriptions
        such as 224224 are recognized as the same underlying family as 224.

    Default maximum block length:
        12

    Block lengths up to 12 are small enough for an exhaustive constrained
    search.  The implementation uses 64-bit integers for block values and
    for 10^m+1 (valid through m=18).

    Usage:
        universal_block_search.exe
        universal_block_search.exe 12

    Output:
        universal_block_families.csv
*/

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <numeric>
#include <random>
#include <sstream>
#include <cstdlib>
#include <string>
#include <unordered_set>
#include <vector>

using u64 = std::uint64_t;
using u128 = unsigned __int128;
using std::string;
using std::vector;

/* ---------- 64-bit modular arithmetic ---------- */

static u64 mul_mod(u64 a, u64 b, u64 mod) {
    return static_cast<u64>((static_cast<u128>(a) * b) % mod);
}

static u64 pow_mod(u64 a, u64 e, u64 mod) {
    u64 r = 1;
    while (e) {
        if (e & 1) r = mul_mod(r, a, mod);
        a = mul_mod(a, a, mod);
        e >>= 1;
    }
    return r;
}

static bool is_prime(u64 n) {
    if (n < 2) return false;

    for (u64 p : {2ULL, 3ULL, 5ULL, 7ULL, 11ULL, 13ULL,
                  17ULL, 19ULL, 23ULL, 29ULL, 31ULL, 37ULL}) {
        if (n % p == 0) return n == p;
    }

    u64 d = n - 1;
    int s = 0;
    while ((d & 1) == 0) {
        d >>= 1;
        ++s;
    }

    // Deterministic for all uint64_t.
    const u64 bases[] = {
        2ULL, 325ULL, 9375ULL, 28178ULL,
        450775ULL, 9780504ULL, 1795265022ULL
    };

    for (u64 a : bases) {
        if (a % n == 0) continue;

        u64 x = pow_mod(a % n, d, n);

        if (x == 1 || x == n - 1) continue;

        bool witness_passed = false;

        for (int r = 1; r < s; ++r) {
            x = mul_mod(x, x, n);
            if (x == n - 1) {
                witness_passed = true;
                break;
            }
        }

        if (!witness_passed) return false;
    }

    return true;
}

/* ---------- Pollard-Rho factorization ---------- */

static u64 rho_f(u64 x, u64 c, u64 mod) {
    return (mul_mod(x, x, mod) + c) % mod;
}

static u64 pollard_rho(u64 n) {
    if (n % 2 == 0) return 2;
    if (n % 3 == 0) return 3;

    static std::mt19937_64 rng(0x8f3a2d71c4e9b125ULL);

    while (true) {
        std::uniform_int_distribution<u64> dist_x(2, n - 2);
        std::uniform_int_distribution<u64> dist_c(1, n - 1);

        u64 x = dist_x(rng);
        u64 y = x;
        u64 c = dist_c(rng);
        u64 d = 1;

        for (int iter = 0; iter < 200000 && d == 1; ++iter) {
            x = rho_f(x, c, n);
            y = rho_f(y, c, n);
            y = rho_f(y, c, n);

            u64 diff = (x > y) ? (x - y) : (y - x);
            d = std::gcd(diff, n);
        }

        if (d != 1 && d != n) return d;
    }
}

static void factor_rec(u64 n, vector<u64>& factors) {
    if (n == 1) return;
    if (is_prime(n)) {
        factors.push_back(n);
        return;
    }

    u64 d = pollard_rho(n);
    factor_rec(d, factors);
    factor_rec(n / d, factors);
}

static vector<u64> distinct_prime_factors(u64 n) {
    vector<u64> factors;
    factor_rec(n, factors);

    std::sort(factors.begin(), factors.end());
    factors.erase(
        std::unique(factors.begin(), factors.end()),
        factors.end()
    );

    return factors;
}

/* ---------- Outer-in transformation ---------- */

static string outer_in(const string& s) {
    string t;
    t.reserve(s.size());

    size_t l = 0;
    size_t r = s.size() - 1;

    while (l <= r) {
        t.push_back(s[l]);
        if (l == r) break;

        t.push_back(s[r]);
        ++l;
        --r;
    }

    return t;
}

/* ---------- Structural constraints ---------- */

/*
    For B of length m, T(BB) must have identical first and second halves.

    We form the equivalence relation on the m positions of B induced by
    that requirement.  Each equivalence class must receive one digit.

    The program enumerates assignments to these classes instead of all
    9*10^(m-2) primitive blocks.
*/

struct DSU {
    vector<int> p;
    vector<int> sz;

    explicit DSU(int n) : p(n), sz(n, 1) {
        for (int i = 0; i < n; ++i) p[i] = i;
    }

    int find(int x) {
        if (p[x] == x) return x;
        return p[x] = find(p[x]);
    }

    void unite(int a, int b) {
        a = find(a);
        b = find(b);
        if (a == b) return;

        if (sz[a] < sz[b]) std::swap(a, b);
        p[b] = a;
        sz[a] += sz[b];
    }
};

static vector<vector<int>> structural_classes(int m) {
    DSU dsu(m);

    /*
       y_j, 0 <= j < 2m, is the digit selected from B.

       For j even:
           y_j = b_(j/2 mod m)

       For j odd:
           y_j = b_(m-1-(j-1)/2 mod m)

       We require y_(j+m) = y_j for 0 <= j < m.
    */

    auto selected_position = [m](int j) -> int {
        if ((j & 1) == 0) {
            return (j / 2) % m;
        }

        int i = (j - 1) / 2;
        int pos = m - 1 - (i % m);
        pos %= m;
        if (pos < 0) pos += m;
        return pos;
    };

    for (int j = m; j < 2 * m; ++j) {
        dsu.unite(
            selected_position(j),
            selected_position(j - m)
        );
    }

    std::vector<int> root_to_class(m, -1);
    vector<vector<int>> classes;

    for (int pos = 0; pos < m; ++pos) {
        int root = dsu.find(pos);

        if (root_to_class[root] == -1) {
            root_to_class[root] = static_cast<int>(classes.size());
            classes.push_back({});
        }

        classes[root_to_class[root]].push_back(pos);
    }

    return classes;
}

/* ---------- Integer helpers ---------- */

static u64 gcd_u64(u64 a, u64 b) {
    return std::gcd(a, b);
}

static u64 digits_to_value(const vector<int>& digits) {
    u64 value = 0;
    for (int d : digits) {
        value = value * 10 + static_cast<u64>(d);
    }
    return value;
}

static string digits_to_string(const vector<int>& digits) {
    string s;
    s.reserve(digits.size());
    for (int d : digits) {
        s.push_back(static_cast<char>('0' + d));
    }
    return s;
}

static int minimal_period(const string& s) {
    const int n = static_cast<int>(s.size());

    for (int p = 1; p <= n; ++p) {
        if (n % p != 0) continue;

        bool ok = true;
        for (int i = p; i < n; ++i) {
            if (s[i] != s[i % p]) {
                ok = false;
                break;
            }
        }

        if (ok) return p;
    }

    return n;
}

static bool is_universal_family(
    u64 A,
    u64 C,
    const vector<u64>& allowed_primes
) {
    u64 g = gcd_u64(A, C);
    u64 a = A / g;
    u64 b = C / g;

    // Every prime factor of a*b must occur in 10^m+1.
    for (u64 p : allowed_primes) {
        while (a % p == 0) a /= p;
        while (b % p == 0) b /= p;
    }

    return a == 1 && b == 1;
}

struct FamilyRow {
    int m = 0;
    string block;
    string transformed;
    int period = 0;
    string canonical_block;
    string canonical_transformed;
    string unmatched;
    u64 modulus = 0;
};

static string factors_to_string(const vector<u64>& factors) {
    if (factors.empty()) return "";

    std::ostringstream out;

    for (size_t i = 0; i < factors.size(); ++i) {
        if (i) out << '*';
        out << factors[i];
    }

    return out.str();
}

int main(int argc, char** argv) {
    const int max_len = (argc >= 2) ? std::stoi(argv[1]) : 12;

    if (max_len < 1 || max_len > 18) {
        std::cerr << "ERROR: maximum supported block length is 18.\n";
        return 1;
    }

    std::ofstream csv("universal_block_families.csv");

    if (!csv) {
        std::cerr << "ERROR: cannot create universal_block_families.csv\n";
        return 1;
    }

    csv << "length,block,transformed_block,minimal_period,"
            "canonical_block,canonical_transformed,"
            "unmatched_prime_factors,10^m_plus_1\n";

    size_t total_blocks = 0;
    size_t structural_blocks = 0;
    size_t universal_seeds = 0;

    std::cout
        << "============================================\n"
        << "Universal repeated-block family search\n"
        << "Block lengths: 1.." << max_len << "\n"
        << "Primitive block: first and last digit nonzero\n"
        << "============================================\n\n";

    for (int m = 1; m <= max_len; ++m) {
        u64 ten_pow_m = 1;

        for (int i = 0; i < m; ++i) {
            ten_pow_m *= 10;
        }

        const u64 modulus = ten_pow_m + 1;
        const vector<u64> allowed_primes =
            distinct_prime_factors(modulus);

        const vector<vector<int>> classes =
            structural_classes(m);

        int first_class = -1;
        int last_class = -1;

        for (int c = 0; c < static_cast<int>(classes.size()); ++c) {
            for (int pos : classes[c]) {
                if (pos == 0) first_class = c;
                if (pos == m - 1) last_class = c;
            }
        }

        std::vector<int> class_digit(classes.size(), 0);
        vector<int> digits(m, 0);

        size_t length_total = 0;
        size_t length_universal = 0;

        /*
            Recursive enumeration of digit assignments to equivalence
            classes.  A class containing the first or last digit must
            receive 1..9; all other classes may receive 0..9.
        */
        std::function<void(int)> dfs =
            [&](int cidx) {
                if (cidx == static_cast<int>(classes.size())) {
                    ++total_blocks;
                    ++length_total;

                    for (int c = 0; c < static_cast<int>(classes.size()); ++c) {
                        for (int pos : classes[c]) {
                            digits[pos] = class_digit[c];
                        }
                    }

                    if (digits[0] == 0 || digits[m - 1] == 0) {
                        return;
                    }

                    const string block = digits_to_string(digits);
                    const string transformed = outer_in(block);

                    if (block == transformed) return;

                    ++structural_blocks;

                    // Independent structural check.
                    const string doubled = block + block;
                    const string transformed_doubled = outer_in(doubled);
                    const string expected = transformed + transformed;

                    if (transformed_doubled != expected) {
                        std::cerr
                            << "INTERNAL ERROR: structural candidate failed: "
                            << block << '\n';
                        std::exit(2);
                    }

                    const u64 A = digits_to_value(digits);
                    const u64 C = std::stoull(transformed);

                    const u64 g = gcd_u64(A, C);
                    u64 a = A / g;
                    u64 b = C / g;

                    vector<u64> unmatched;

                    for (u64 x = a; ; ) {
                        if (x == 1) break;

                        bool removed = false;

                        for (u64 p : allowed_primes) {
                            if (x % p == 0) {
                                removed = true;
                                while (x % p == 0) x /= p;
                            }
                        }

                        if (!removed) break;
                    }

                    for (u64 x = b; ; ) {
                        if (x == 1) break;

                        bool removed = false;

                        for (u64 p : allowed_primes) {
                            if (x % p == 0) {
                                removed = true;
                                while (x % p == 0) x /= p;
                            }
                        }

                        if (!removed) break;
                    }

                    if (!is_universal_family(A, C, allowed_primes)) {
                        return;
                    }

                    ++universal_seeds;
                    ++length_universal;

                    const int period = minimal_period(block);

                    string canonical_block = block;
                    string canonical_transformed = transformed;

                    if (period < m) {
                        canonical_block = block.substr(0, period);
                        canonical_transformed = outer_in(
                            canonical_block
                        );
                    }

                    csv << m << ','
                        << block << ','
                        << transformed << ','
                        << period << ','
                        << canonical_block << ','
                        << canonical_transformed << ','
                        << "\"\""
                        << ','
                        << modulus
                        << '\n';

                    std::cout
                        << "FAMILY  "
                        << block
                        << " -> "
                        << transformed
                        << "   period="
                        << period
                        << "   canonical="
                        << canonical_block
                        << " -> "
                        << canonical_transformed
                        << "   10^m+1="
                        << modulus
                        << " = "
                        << factors_to_string(allowed_primes)
                        << '\n';

                    // Independent r=1 and r=2 checks.
                    const string b2 = block + block;
                    const string c2 = transformed + transformed;
                    const string b4 = b2 + b2;
                    const string c4 = c2 + c2;

                    if (outer_in(b2) != c2 ||
                        outer_in(b4) != c4) {
                        std::cerr
                            << "INTERNAL ERROR: repeated-block verification failed: "
                            << block << '\n';
                        std::exit(3);
                    }

                    // Ensure the universal criterion itself agrees with
                    // the explicit support test at the r=1 example.
                    const u64 A2 = digits_to_value(
                        vector<int>(digits.begin(), digits.end())
                    );

                    (void)A2;
                    return;
                }

                const bool restricted =
                    (cidx == first_class || cidx == last_class);

                const int start_digit = restricted ? 1 : 0;
                const int end_digit = 9;

                for (int d = start_digit; d <= end_digit; ++d) {
                    class_digit[cidx] = d;
                    dfs(cidx + 1);
                }
            };

        dfs(0);

        std::cout
            << "m=" << m
            << "   equivalence_classes=" << classes.size()
            << "   structural_blocks=" << length_total
            << "   universal_seeds=" << length_universal
            << "   factors(10^m+1)="
            << factors_to_string(allowed_primes)
            << '\n';
    }

    std::cout
        << "\n============================================\n"
        << "Total structural blocks tested: "
        << structural_blocks << '\n'
        << "Universal seed rows:             "
        << universal_seeds << '\n'
        << "CSV: universal_block_families.csv\n";

    return 0;
}
