/*
    family_lift_search.cpp  (corrected)

    Search for "lifted" repeated-block constructions.

    Let B be an m-digit primitive block and C=T(B).  Suppose

        T(BB) = CC.

    Then for every k >= 1,

        T(B^(2k)) = C^(2k).

    Write A=[B] and C0=[C].  The even repetition of B by a factor s
    can be viewed as a repeated block of length m*s.  Its common
    repetition factor is

        Q_{r,s} = 1 + 10^(m*s) + ... + 10^((2r-1)m*s).

    If every prime in the support difference

        P(A) XOR P(C0)

    divides

        10^(m*s) + 1,

    then the repeated construction at lift s preserves prime support
    for every r >= 1.

    Thus this program searches, for each structurally eligible base B,
    for multipliers s such that every unmatched prime is a divisor of
    10^(m*s)+1.

    IMPORTANT:
      - This program studies one construction mechanism only.
      - It does not classify all infinite families of the original
        problem.
      - It does not require B and C themselves to have equal prime
        support; the lift factor may supply missing primes.
      - A result at s is a family construction.  The actual first
        solution has 2*s copies of the base block B.

    The implementation uses direct modular exponentiation rather than
    factoring 10^(m*s)+1.

    Usage:
        family_lift_search.exe 6 200

    Arguments:
        1. maximum base-block length (default 6)
        2. maximum lift multiplier s (default 200)

    Output:
        family_lift_results.csv
*/

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using std::string;
using std::vector;

/* ---------------- Outer-in transformation ---------------- */

static string outer_in(const string& s) {
    string t;
    t.reserve(s.size());

    size_t left = 0;
    size_t right = s.size() - 1;

    while (left <= right) {
        t.push_back(s[left]);

        if (left == right)
            break;

        t.push_back(s[right]);

        ++left;
        --right;
    }

    return t;
}

/* ---------------- Small integer factorization ---------------- */

static vector<u64> distinct_prime_factors(u64 x) {
    vector<u64> factors;

    if (x <= 1)
        return factors;

    if (x % 2 == 0) {
        factors.push_back(2);

        while (x % 2 == 0)
            x /= 2;
    }

    for (u64 p = 3; p <= x / p; p += 2) {
        if (x % p == 0) {
            factors.push_back(p);

            while (x % p == 0)
                x /= p;
        }
    }

    if (x > 1)
        factors.push_back(x);

    return factors;
}

static bool contains(
    const vector<u64>& values,
    u64 x
) {
    return std::binary_search(
        values.begin(),
        values.end(),
        x
    );
}

static vector<u64> support_difference(
    const vector<u64>& a,
    const vector<u64>& b
) {
    vector<u64> diff;

    for (u64 p : a) {
        if (!contains(b, p))
            diff.push_back(p);
    }

    for (u64 p : b) {
        if (!contains(a, p))
            diff.push_back(p);
    }

    std::sort(diff.begin(), diff.end());
    diff.erase(
        std::unique(diff.begin(), diff.end()),
        diff.end()
    );

    return diff;
}

static string join_factors(
    const vector<u64>& factors
) {
    if (factors.empty())
        return "";

    std::ostringstream out;

    for (size_t i = 0; i < factors.size(); ++i) {
        if (i)
            out << '*';

        out << factors[i];
    }

    return out.str();
}

/* ---------------- Modular arithmetic ---------------- */

static u64 mul_mod(
    u64 a,
    u64 b,
    u64 mod
) {
    return static_cast<u64>(
        (static_cast<unsigned __int128>(a) * b) % mod
    );
}

static u64 pow_mod(
    u64 a,
    u64 e,
    u64 mod
) {
    if (mod == 1)
        return 0;

    u64 result = 1;

    while (e) {
        if (e & 1ULL)
            result = mul_mod(result, a, mod);

        a = mul_mod(a, a, mod);
        e >>= 1;
    }

    return result;
}

/* ---------------- Structural position classes ---------------- */

struct DSU {
    vector<int> parent;
    vector<int> size;

    explicit DSU(int n)
        : parent(n), size(n, 1) {

        for (int i = 0; i < n; ++i)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] == x)
            return x;

        return parent[x] = find(parent[x]);
    }

    void unite(int a, int b) {
        a = find(a);
        b = find(b);

        if (a == b)
            return;

        if (size[a] < size[b])
            std::swap(a, b);

        parent[b] = a;
        size[a] += size[b];
    }
};

/*
    Build the digit-position equivalence classes forced by

        T(BB) = CC.

    A digit assignment to one class is copied to every position in
    that class.
*/
static vector<vector<int>> build_classes(int m) {
    DSU dsu(m);

    auto selected_position = [m](int j) -> int {
        if ((j & 1) == 0)
            return (j / 2) % m;

        const int i = (j - 1) / 2;
        return (m - 1 - (i % m) + m) % m;
    };

    for (int j = m; j < 2 * m; ++j) {
        dsu.unite(
            selected_position(j),
            selected_position(j - m)
        );
    }

    vector<int> root_to_class(m, -1);
    vector<vector<int>> classes;

    for (int pos = 0; pos < m; ++pos) {
        const int root = dsu.find(pos);

        if (root_to_class[root] == -1) {
            root_to_class[root] =
                static_cast<int>(classes.size());

            classes.push_back({});
        }

        classes[root_to_class[root]].push_back(pos);
    }

    return classes;
}

/* ---------------- Decimal conversion ---------------- */

static u64 digits_to_value(
    const vector<int>& digits
) {
    u64 value = 0;

    for (int d : digits)
        value = value * 10ULL + static_cast<u64>(d);

    return value;
}

static u64 digits_to_value(
    const string& digits
) {
    u64 value = 0;

    for (char c : digits) {
        value = value * 10ULL +
                static_cast<u64>(c - '0');
    }

    return value;
}

static string digits_to_string(
    const vector<int>& digits
) {
    string s;
    s.reserve(digits.size());

    for (int d : digits)
        s.push_back(
            static_cast<char>('0' + d)
        );

    return s;
}

/* ---------------- Main search ---------------- */

int main(
    int argc,
    char** argv
) {
    const int max_base =
        (argc >= 2) ? std::stoi(argv[1]) : 6;

    const int max_lift =
        (argc >= 3) ? std::stoi(argv[2]) : 200;

    if (max_base < 1 || max_base > 12) {
        std::cerr
            << "ERROR: base length must be between 1 and 12.\n";

        return 1;
    }

    if (max_lift < 1 || max_lift > 100000) {
        std::cerr
            << "ERROR: lift multiplier must be between 1 and 100000.\n";

        return 1;
    }

    std::ofstream csv(
        "family_lift_results.csv"
    );

    if (!csv) {
        std::cerr
            << "ERROR: cannot create family_lift_results.csv\n";

        return 1;
    }

    csv
        << "base_length,"
           "base_block,"
           "base_transformed,"
           "base_period,"
           "repeat_multiplier,"
           "lifted_block_length,"
           "first_solution_length,"
           "support_difference,"
           "criterion,"
           "status\n";

    size_t structural_bases = 0;
    size_t lift_rows = 0;

    std::cout
        << "============================================\n"
        << "Period-lift universal-family search\n"
        << "Corrected implementation\n"
        << "============================================\n"
        << "Base lengths: 1.." << max_base << '\n'
        << "Lift multipliers: 1.." << max_lift << '\n'
        << "Primitive base block\n"
        << "============================================\n\n";

    for (int m = 1; m <= max_base; ++m) {
        const vector<vector<int>> classes =
            build_classes(m);

        int first_class = -1;
        int last_class = -1;

        for (int c = 0;
             c < static_cast<int>(classes.size());
             ++c) {

            for (int pos : classes[c]) {
                if (pos == 0)
                    first_class = c;

                if (pos == m - 1)
                    last_class = c;
            }
        }

        vector<int> class_digit(
            classes.size(),
            0
        );

        vector<int> digits(
            m,
            0
        );

        size_t local_bases = 0;
        size_t local_lifts = 0;

        std::function<void(int)> dfs =
            [&](int class_index) {

                if (class_index ==
                    static_cast<int>(classes.size())) {

                    // Expand the class assignment into actual digits.
                    for (int c = 0;
                         c < static_cast<int>(classes.size());
                         ++c) {

                        for (int pos : classes[c])
                            digits[pos] = class_digit[c];
                    }

                    // Primitive m-digit block.
                    if (digits[0] == 0 ||
                        digits[m - 1] == 0)
                        return;

                    const string B =
                        digits_to_string(digits);

                    const string C =
                        outer_in(B);

                    if (B == C)
                        return;

                    // Structural verification.
                    const string BB = B + B;
                    const string expected_CC = C + C;

                    if (outer_in(BB) != expected_CC) {
                        std::cerr
                            << "INTERNAL ERROR: "
                               "T(BB) != CC for "
                            << B << '\n';

                        std::exit(2);
                    }

                    ++structural_bases;
                    ++local_bases;

                    const u64 A =
                        digits_to_value(digits);

                    const u64 C0 =
                        digits_to_value(C);

                    const vector<u64> pA =
                        distinct_prime_factors(A);

                    const vector<u64> pC =
                        distinct_prime_factors(C0);

                    const vector<u64> diff =
                        support_difference(pA, pC);

                    /*
                        If the base already has matching support,
                        it is already a universal family at lift s=1.
                        There is no need to report all multiples of s,
                        because they are the same underlying family.
                    */
                    if (diff.empty())
                        return;

                    /*
                        Q_r is odd. Therefore an unmatched factor 2
                        can never be supplied by the repetition factor.
                    */
                    if (contains(diff, 2))
                        return;

                    /*
                        Search for the smallest lift s first.

                        If s works, every multiple of s also works:
                        10^(m*s) == -1 (mod p) implies the same for
                        any odd multiple, and even multiples give +1,
                        so we deliberately do NOT assume monotonicity.
                        We test each s independently.
                    */
                    for (int s = 1;
                         s <= max_lift;
                         ++s) {

                        const long long lifted_length =
                            1LL * m * s;

                        bool works = true;

                        for (u64 p : diff) {

                            if (p == 2) {
                                works = false;
                                break;
                            }

                            const u64 residue =
                                pow_mod(
                                    10 % p,
                                    static_cast<u64>(
                                        lifted_length
                                    ),
                                    p
                                );

                            if (residue != p - 1) {
                                works = false;
                                break;
                            }
                        }

                        if (!works)
                            continue;

                        ++lift_rows;
                        ++local_lifts;

                        const long long first_solution_length =
                            2LL * lifted_length;

                        csv
                            << m << ','
                            << B << ','
                            << C << ','
                            << "N/A" << ','
                            << s << ','
                            << lifted_length << ','
                            << first_solution_length << ','
                            << '"'
                            << join_factors(diff)
                            << '"' << ','
                            << "10^(m*s) == -1 mod p "
                               "for every support-difference prime"
                            << ','
                            << "VERIFIED_BY_CRITERION"
                            << '\n';

                        std::cout
                            << "LIFT  "
                            << B
                            << " -> "
                            << C
                            << "  s="
                            << s
                            << "  seed_length="
                            << lifted_length
                            << "  first_solution_length="
                            << first_solution_length
                            << "  support_diff={"
                            << join_factors(diff)
                            << "}\n";
                    }

                    return;
                }

                const bool endpoint_class =
                    (class_index == first_class ||
                     class_index == last_class);

                const int low =
                    endpoint_class ? 1 : 0;

                for (int d = low;
                     d <= 9;
                     ++d) {

                    class_digit[class_index] = d;
                    dfs(class_index + 1);
                }
            };

        dfs(0);

        std::cout
            << "m=" << m
            << "  structural_bases="
            << local_bases
            << "  lift_rows="
            << local_lifts
            << "  classes="
            << classes.size()
            << '\n';
    }

    std::cout
        << "\n============================================\n"
        << "Structural base blocks: "
        << structural_bases << '\n'
        << "Universal lift rows:    "
        << lift_rows << '\n'
        << "CSV: family_lift_results.csv\n"
        << "============================================\n";

    return 0;
}
