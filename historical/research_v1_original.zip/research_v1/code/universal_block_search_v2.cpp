/*
    universal_block_search_v2.cpp

    Corrected search for universal repeated-block families.

    IMPORTANT MATHEMATICAL CONDITION
    --------------------------------
    Let B be an m-digit block and suppose

        T(BB) = CC

    for an m-digit block C.

    For 2r copies of B,

        value(B^(2r)) = A Q_r
        value(C^(2r)) = C0 Q_r

    where

        Q_r = 1 + 10^m + ... + 10^((2r-1)m).

    Let g = gcd(A,C0).

    A repeated-block family preserves prime support for EVERY r >= 1
    iff every prime in the symmetric difference

        P(A) XOR P(C0)

    divides 10^m + 1.

    Equivalently, writing A = a g and C0 = b g with gcd(a,b)=1,
    every prime divisor of a*b must divide g*(10^m+1).

    The previous version of this program incorrectly required every
    prime factor of a*b to divide 10^m+1, forgetting that a prime can
    already occur in g. That incorrectly rejected the 224 -> 242 family.

    This version uses the correct criterion.

    The program searches structurally eligible primitive blocks for
    lengths 1..MAX_LEN. The structural condition is reduced using the
    digit-position equivalence classes induced by T(BB)=CC.

    Usage:
        universal_block_search_v2.exe
        universal_block_search_v2.exe 12

    Output:
        universal_block_families_v2.csv
*/

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iostream>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

using u64 = std::uint64_t;
using u128 = unsigned __int128;
using std::string;
using std::vector;

/* ---------------- arithmetic ---------------- */

static u64 mul_mod(u64 a, u64 b, u64 mod) {
    return static_cast<u64>((static_cast<u128>(a) * b) % mod);
}

static u64 pow_mod(u64 a, u64 e, u64 mod) {
    u64 r = 1;
    while (e) {
        if (e & 1) r = mul_mod(r, a, mod);
        a = mul_mod(a, a, mod);
        e >>= 1;
    }
    return r;
}

static bool is_prime(u64 n) {
    if (n < 2) return false;

    for (u64 p : {2ULL, 3ULL, 5ULL, 7ULL, 11ULL, 13ULL,
                  17ULL, 19ULL, 23ULL, 29ULL, 31ULL, 37ULL}) {
        if (n % p == 0) return n == p;
    }

    u64 d = n - 1;
    int s = 0;

    while ((d & 1) == 0) {
        d >>= 1;
        ++s;
    }

    const u64 bases[] = {
        2ULL, 325ULL, 9375ULL, 28178ULL,
        450775ULL, 9780504ULL, 1795265022ULL
    };

    for (u64 a : bases) {
        if (a % n == 0) continue;

        u64 x = pow_mod(a % n, d, n);

        if (x == 1 || x == n - 1) continue;

        bool ok = false;

        for (int r = 1; r < s; ++r) {
            x = mul_mod(x, x, n);

            if (x == n - 1) {
                ok = true;
                break;
            }
        }

        if (!ok) return false;
    }

    return true;
}

static u64 rho_f(u64 x, u64 c, u64 mod) {
    return (mul_mod(x, x, mod) + c) % mod;
}

static u64 pollard_rho(u64 n) {
    if (n % 2 == 0) return 2;
    if (n % 3 == 0) return 3;

    static std::uint64_t state = 0x9e3779b97f4a7c15ULL;

    auto next_rand = [&]() -> u64 {
        state ^= state >> 12;
        state ^= state << 25;
        state ^= state >> 27;
        return state * 2685821657736338717ULL;
    };

    while (true) {
        u64 x = 2 + next_rand() % (n - 3);
        u64 y = x;
        u64 c = 1 + next_rand() % (n - 1);
        u64 d = 1;

        for (int iter = 0; iter < 200000 && d == 1; ++iter) {
            x = rho_f(x, c, n);
            y = rho_f(y, c, n);
            y = rho_f(y, c, n);

            u64 diff = (x > y) ? x - y : y - x;
            d = std::gcd(diff, n);
        }

        if (d != 1 && d != n) return d;
    }
}

static void factor_rec(u64 n, vector<u64>& f) {
    if (n == 1) return;

    if (is_prime(n)) {
        f.push_back(n);
        return;
    }

    u64 d = pollard_rho(n);
    factor_rec(d, f);
    factor_rec(n / d, f);
}

static vector<u64> distinct_prime_factors(u64 n) {
    vector<u64> f;
    factor_rec(n, f);

    std::sort(f.begin(), f.end());
    f.erase(std::unique(f.begin(), f.end()), f.end());

    return f;
}

/* ---------------- transformation ---------------- */

static string outer_in(const string& s) {
    string t;
    t.reserve(s.size());

    size_t l = 0;
    size_t r = s.size() - 1;

    while (l <= r) {
        t.push_back(s[l]);

        if (l == r) break;

        t.push_back(s[r]);
        ++l;
        --r;
    }

    return t;
}

/* ---------------- digit-position structure ---------------- */

struct DSU {
    vector<int> parent;
    vector<int> size;

    explicit DSU(int n) : parent(n), size(n, 1) {
        for (int i = 0; i < n; ++i)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] == x) return x;
        return parent[x] = find(parent[x]);
    }

    void unite(int a, int b) {
        a = find(a);
        b = find(b);

        if (a == b) return;

        if (size[a] < size[b]) std::swap(a, b);

        parent[b] = a;
        size[a] += size[b];
    }
};

static vector<vector<int>> build_classes(int m) {
    DSU dsu(m);

    auto selected_position = [m](int j) -> int {
        if ((j & 1) == 0) {
            return (j / 2) % m;
        }

        int i = (j - 1) / 2;
        return (m - 1 - (i % m)) % m;
    };

    for (int j = m; j < 2 * m; ++j) {
        dsu.unite(
            selected_position(j),
            selected_position(j - m)
        );
    }

    vector<int> root_to_class(m, -1);
    vector<vector<int>> classes;

    for (int pos = 0; pos < m; ++pos) {
        int root = dsu.find(pos);

        if (root_to_class[root] == -1) {
            root_to_class[root] =
                static_cast<int>(classes.size());
            classes.push_back({});
        }

        classes[root_to_class[root]].push_back(pos);
    }

    return classes;
}

/* ---------------- helpers ---------------- */

static u64 digits_to_value(const vector<int>& digits) {
    u64 x = 0;

    for (int d : digits) {
        x = x * 10 + static_cast<u64>(d);
    }

    return x;
}

static string digits_to_string(const vector<int>& digits) {
    string s;
    s.reserve(digits.size());

    for (int d : digits)
        s.push_back(static_cast<char>('0' + d));

    return s;
}

static bool contains(const vector<u64>& v, u64 x) {
    return std::binary_search(v.begin(), v.end(), x);
}

static string join_factors(const vector<u64>& v) {
    if (v.empty()) return "";

    std::ostringstream out;

    for (size_t i = 0; i < v.size(); ++i) {
        if (i) out << '*';
        out << v[i];
    }

    return out.str();
}

/*
    Determine whether every prime divisor of x also divides the
    128-bit modulus M.

    x is <= 64-bit, M can be larger than 64-bit.

    If gcd(x,M) > 1, dividing x by that gcd removes at least one
    exponent of every prime shared by x and M. Repeating reaches 1
    iff all primes of x divide M.
*/
static bool all_prime_factors_divide_u128(u64 x, u128 M) {
    while (x != 1) {
        u64 remainder = static_cast<u64>(M % x);
        u64 d = std::gcd(x, remainder);

        if (d == 1) return false;

        x /= d;
    }

    return true;
}

/*
    Correct universal criterion.

    Let g = gcd(A,C), a=A/g, b=C/g.

    Support equality for every r is equivalent to

        rad(a*b) | g*(10^m+1).

    Since a and b are coprime, it is sufficient to test each separately.
*/
static bool universal_support(
    u64 A,
    u64 C,
    u64 modulus
) {
    const u64 g = std::gcd(A, C);
    const u64 a = A / g;
    const u64 b = C / g;

    const u128 allowed =
        static_cast<u128>(g) *
        static_cast<u128>(modulus);

    return
        all_prime_factors_divide_u128(a, allowed) &&
        all_prime_factors_divide_u128(b, allowed);
}

static int minimal_period(const string& s) {
    const int n = static_cast<int>(s.size());

    for (int p = 1; p <= n; ++p) {
        if (n % p != 0) continue;

        bool ok = true;

        for (int i = p; i < n; ++i) {
            if (s[i] != s[i % p]) {
                ok = false;
                break;
            }
        }

        if (ok) return p;
    }

    return n;
}

/* ---------------- main search ---------------- */

int main(int argc, char** argv) {
    const int max_len =
        (argc >= 2) ? std::stoi(argv[1]) : 12;

    if (max_len < 1 || max_len > 18) {
        std::cerr
            << "ERROR: maximum block length is 18.\n";
        return 1;
    }

    std::ofstream csv("universal_block_families_v2.csv");

    if (!csv) {
        std::cerr
            << "ERROR: cannot create CSV output.\n";
        return 1;
    }

    csv
        << "length,block,transformed_block,"
           "minimal_period,unmatched_prime_factors,"
           "10^m_plus_1,family_type,two_blocks,"
           "transformed_two_blocks,first_family_member,"
           "first_transformed_member\n";

    size_t total_structural_candidates = 0;
    size_t universal_rows = 0;

    std::cout
        << "============================================\n"
        << "Universal repeated-block family search v2\n"
        << "Correct prime-support criterion\n"
        << "Block lengths: 1.." << max_len << "\n"
        << "Primitive block: first and last digit nonzero\n"
        << "============================================\n\n";

    for (int m = 1; m <= max_len; ++m) {
        u64 ten_pow_m = 1;

        for (int i = 0; i < m; ++i)
            ten_pow_m *= 10;

        const u64 modulus = ten_pow_m + 1;

        const vector<u64> modulus_factors =
            distinct_prime_factors(modulus);

        const auto classes = build_classes(m);

        int first_class = -1;
        int last_class = -1;

        for (int c = 0;
             c < static_cast<int>(classes.size());
             ++c) {

            for (int pos : classes[c]) {
                if (pos == 0)
                    first_class = c;

                if (pos == m - 1)
                    last_class = c;
            }
        }

        vector<int> class_digit(classes.size(), 0);
        vector<int> digits(m, 0);

        size_t length_candidates = 0;
        size_t length_universal = 0;

        std::function<void(int)> dfs =
            [&](int class_index) {

                if (class_index ==
                    static_cast<int>(classes.size())) {

                    ++total_structural_candidates;
                    ++length_candidates;

                    for (int c = 0;
                         c < static_cast<int>(classes.size());
                         ++c) {

                        for (int pos : classes[c])
                            digits[pos] = class_digit[c];
                    }

                    if (digits[0] == 0 ||
                        digits[m - 1] == 0)
                        return;

                    const string block =
                        digits_to_string(digits);

                    const string transformed =
                        outer_in(block);

                    if (block == transformed)
                        return;

                    const string doubled =
                        block + block;

                    const string transformed_doubled =
                        outer_in(doubled);

                    const string expected =
                        transformed + transformed;

                    if (transformed_doubled != expected) {
                        std::cerr
                            << "INTERNAL ERROR: T(BB) != CC for "
                            << block << '\n';
                        std::exit(2);
                    }

                    if (universal_support(
                            digits_to_value(digits),
                            std::stoull(transformed),
                            modulus)) {

                        ++universal_rows;
                        ++length_universal;

                        const int period =
                            minimal_period(block);

                        /*
                            We report the actual seed that produced the
                            universal family. A shorter periodic description
                            can have a different repetition modulus and
                            therefore must NOT automatically be treated as
                            equivalent.
                        */

                        // Unmatched prime factors:
                        const u64 A = digits_to_value(digits);
                        const u64 C =
                            std::stoull(transformed);
                        const u64 g = std::gcd(A, C);

                        vector<u64> fa =
                            distinct_prime_factors(A / g);
                        vector<u64> fc =
                            distinct_prime_factors(C / g);

                        vector<u64> unmatched = fa;

                        for (u64 p : fc)
                            if (!contains(unmatched, p))
                                unmatched.push_back(p);

                        std::sort(unmatched.begin(), unmatched.end());

                        const string two =
                            doubled;
                        const string two_t =
                            transformed_doubled;

                        const string first_family_member =
                            doubled;
                        const string first_transformed_member =
                            transformed_doubled;

                        csv
                            << m << ','
                            << block << ','
                            << transformed << ','
                            << period << ','
                            << '"'
                            << join_factors(unmatched)
                            << '"' << ','
                            << modulus << ','
                            << "UNIVERSAL" << ','
                            << two << ','
                            << two_t << ','
                            << first_family_member << ','
                            << first_transformed_member
                            << '\n';

                        std::cout
                            << "FAMILY  "
                            << block
                            << " -> "
                            << transformed
                            << "  period="
                            << period
                            << "  unmatched_primes={"
                            << join_factors(unmatched)
                            << "}"
                            << "  10^m+1="
                            << modulus
                            << " = "
                            << join_factors(modulus_factors)
                            << '\n';
                    }

                    return;
                }

                const bool restricted =
                    (class_index == first_class ||
                     class_index == last_class);

                const int lo =
                    restricted ? 1 : 0;

                for (int d = lo; d <= 9; ++d) {
                    class_digit[class_index] = d;
                    dfs(class_index + 1);
                }
            };

        dfs(0);

        std::cout
            << "m=" << m
            << "  classes=" << classes.size()
            << "  candidates="
            << length_candidates
            << "  universal="
            << length_universal
            << "  factors(10^m+1)="
            << join_factors(modulus_factors)
            << '\n';
    }

    std::cout
        << "\n============================================\n"
        << "Structural candidates tested: "
        << total_structural_candidates << '\n'
        << "Universal family rows:        "
        << universal_rows << '\n'
        << "CSV: universal_block_families_v2.csv\n";

    return 0;
}
