# v1.2 Corrections — 2026-09-22

1. The known primitive example set is now 39 distinct values, after adding
   three independently verified members of the 117117117 / 171171171 family.

2. Provenance counts are:
   - 19 globally exhaustive below 1e9;
   - 11 proven-family members;
   - 9 ratio-restricted discoveries.

3. The repeated-block universal criterion is recorded in terms of the
   symmetric difference of prime-support sets:
       P(A) XOR P(C) subset P(10^m + 1).

4. The older v2 block-search program has a presentation bug in its
   `unmatched_prime_factors` CSV column. Its universal-support test is
   not being used as public evidence from that column. The mathematical
   statement is corrected in the v1.2 documents.

5. No claim is made that the 39 examples form the complete sequence beyond
   the globally exhaustive n < 1e9 range.

6. The 117117117 / 171171171 construction is treated as a proven infinite
   family only after its first member and additional members were independently
   verified.
