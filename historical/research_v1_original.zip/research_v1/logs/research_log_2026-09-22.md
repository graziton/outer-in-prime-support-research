# Research Log — Snapshot v1

## 2026-09-22

### Backup
Full working directory copied to:
`D:\OEIS_backup_2026-09-22`

### Inventory
Created:
`D:\OEIS\research_inventory.txt`

### Research tree
Created:
`D:\OEIS\research_v1`

Subdirectories:
- `code`
- `data`
- `analysis`
- `logs`

### Independent verifier
Program:
`code/verify_solutions.cpp`

Compiled with:
`g++ -O2 -std=c++17 verify_solutions.cpp -o verify_solutions.exe`

The verifier independently recomputes the outer-in transformation and checks the prime-support condition.

### First audit
32 candidate integers were checked.

Result:
- Candidates read: 32
- Verified matches: 32
- Non-verified outcomes: 0

SHA-256:
`verify_solutions.cpp`
`B05D3A564FE69E4E61508CD404C0CA48DAB914D155AB0B343CD569EF7E1F37CD`

`verification_audit.csv`
`32B6560F49CE537FBD14C6663F994382D62C493708879C9996E64C9BCCD1EE73`

### Expanded known-example set
Four additional members of the proven 112:121 repeated-block families were added:

- 224224224224224224224224 -> 242242242242242242242242
- 448448448448448448448448 -> 484484484484484484484484
- 224224224224224224224224224224 -> 242242242242242242242242242242
- 448448448448448448448448448448 -> 484484484484484484484484484484

All 36 entries in the expanded known-example set were independently verified.

## Search provenance retained

The original working directory retains historical and current programs, including:

- `search.cpp`
- `search_9digit_fast.cpp`
- `ratio_solver.cpp`
- `outer_in_ratio_search.cpp`
- `analyze.cpp`
- `orbit_analysis.cpp`
- `research_analysis.cpp`
- `support_ratio_search_clean.cpp`

The raw CSV and orbit-analysis files are also retained.

## Important status rule

A ratio-search result marked `INCOMPLETE` must never be interpreted as a proof that no solution exists at that digit length.

## Public-release rule

This snapshot is an internal draft. Before public release:

1. perform a broader novelty/literature search;
2. review all mathematical statements;
3. independently reproduce the key results;
4. decide on the exact sequence formulation to submit to OEIS;
5. decide how AI assistance will be disclosed under the rules of the eventual venue.
