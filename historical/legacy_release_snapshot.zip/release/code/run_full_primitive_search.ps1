$ErrorActionPreference = "Stop"

$exe = Join-Path $PSScriptRoot "exhaustive_search.exe"
if (-not (Test-Path $exe)) {
    throw "Missing executable: $exe"
}

$threads = 8
$chunk   = [int64]2000000
$rawDir  = Join-Path $PSScriptRoot "raw"
if (-not (Test-Path $rawDir)) {
    New-Item -ItemType Directory -Path $rawDir | Out-Null
}

$rawFiles = @()

# One complete decimal digit length per invocation.
# This avoids any ambiguity in the digit-position mapping.
for ($digits = 1; $digits -le 10; ++$digits) {
    [int64]$lo = 1
    for ($i = 1; $i -lt $digits; ++$i) {
        $lo *= 10
    }
    [int64]$hi = $lo * 10

    $file = Join-Path $rawDir ("hits_{0}digit.csv" -f $digits)
    $rawFiles += $file

    Write-Host "========================================"
    Write-Host "Digit length: $digits"
    Write-Host "Scanning [$lo,$hi)"
    Write-Host "Output: $file"
    Write-Host "========================================"

    & $exe $lo $hi $threads $chunk $file

    if ($LASTEXITCODE -ne 0) {
        throw "Search failed for [$lo,$hi)"
    }
}

# Consolidate all raw hits into one sorted CSV.
$rows = foreach ($file in $rawFiles) {
    Import-Csv $file
}

$allFile = Join-Path $PSScriptRoot "primitive_hits_all.csv"
$rows |
    Sort-Object { [int64]$_.n } |
    Export-Csv $allFile -NoTypeInformation

Write-Host ""
Write-Host "========================================"
Write-Host "FULL SEARCH COMPLETE"
Write-Host "Combined output: $allFile"
Write-Host "Hit count: $($rows.Count)"
Write-Host "========================================"
