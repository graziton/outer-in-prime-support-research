# Outer-in Prime-Support Research — Release Package (Draft)

## Research object

For a decimal integer with digit string

    n = d1 d2 ... dk,

define the outer-in transformation

    T(n) = d1 dk d2 d{k-1} d3 d{k-2} ...

The sequence studied here consists of positive integers n satisfying

    n != T(n),
    rad(n) = rad(T(n)),

and, for the primitive sequence used in this project,

    n does not end in 0.

Here rad(m) is the product of the distinct prime divisors of m.

## Exact criterion

Let

    g = gcd(n,T(n)),
    n = a g,
    T(n) = b g,
    gcd(a,b) = 1.

Then

    rad(n) = rad(T(n))

if and only if

    rad(a b) | g.

Equivalently,

    a * rad(a b) | n.

## Exhaustive computational result

The ratio-independent search establishes the complete primitive list for

    n < 10^10.

It contains exactly 22 terms.

19 terms are below 10^9 and 3 terms lie in

    10^9 <= n < 10^10.

The canonical 22-term dataset and b-file are provided under `data/` and `oeis/`.

## Reproducibility

The exhaustive-search source is:

    code/exhaustive_search.cpp

It implements the same ratio-independent algorithm used for the completed 10-digit scan. The internal research archive retains the historical source under `research_v1/code/ratio_independent_search_v2.cpp`.

Compile on Windows with MinGW/G++:

    g++ -O3 -std=c++17 -pthread .\exhaustive_search.cpp -o .\exhaustive_search.exe

For the complete primitive result, run:

    code/run_full_primitive_search.ps1

The runner invokes the search separately for each decimal digit length 1 through 10:

    [1,10)
    [10,100)
    ...
    [10^9,10^10)

Each invocation uses 8 threads and a 2,000,000-number work chunk. The runner then consolidates and sorts the raw hits.

The single-length restriction is deliberate: the search constructs a fixed decimal digit permutation for the digit length being scanned.

The search program uses 64-bit unsigned integers. It is intended for the 1-to-10-digit exhaustive computations in this package, not for arbitrary-precision search.

## Independent verification

The independent verifier is:

    code/verify_solutions.cpp

The corresponding candidate list is:

    verification/final_22_verification_input.txt

Compile:

    g++ -O3 -std=c++17 .\verify_solutions.cpp -o .\verify_solutions.exe

Run:

    .\verify_solutions.exe ..\verification\final_22_verification_input.txt ..\verification\verified_solutions.csv

The completed verification run reported 22 candidates read, 22 verified matches, and 0 non-verified outcomes.

## Important scope statement

The `22-term` statement is a completeness statement only for the primitive sequence and only for the range n < 10^10.

It does not claim that the sequence is completely classified beyond 10^10.

The project also contains separate ratio-restricted searches and repeated-block-family investigations. Those are supporting research and are not required to establish the 22-term exhaustive initial segment.

## Public-release status

This package is a clean draft release package prepared from the internal research archive. It is not itself an OEIS submission and should not be treated as a priority claim.

Before public submission, the OEIS entry and manuscript should undergo a final consistency and novelty/reference review.
