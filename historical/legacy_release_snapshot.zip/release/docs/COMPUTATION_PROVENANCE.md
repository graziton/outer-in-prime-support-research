# Computation provenance

The project originally developed several search programs. The definitive
ratio-independent search used for the completed 10-digit interval is retained
in the internal archive as:

    research_v1/code/ratio_independent_search_v2.cpp

The clean release source `code/exhaustive_search.cpp` is the same search
algorithm packaged without project-specific history. It accepts one fixed
decimal digit length per invocation.

The completed base computation consisted of:

- the globally exhaustive primitive search below 10^9;
- the corrected ratio-independent exhaustive search over the entire
  10^9 <= n < 10^10 interval.

The final canonical dataset combines those results and contains 22 distinct
terms.

For archival audit purposes, the original research folder retains all raw
10-digit chunk outputs and earlier search versions.
