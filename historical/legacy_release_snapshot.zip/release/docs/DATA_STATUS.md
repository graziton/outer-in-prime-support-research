# Data Status

The canonical primitive dataset contains 22 distinct terms.

The exhaustive computation has two components:

1. the previously completed globally exhaustive primitive search for n < 10^9, yielding 19 terms;
2. the completed ratio-independent scan of the full 10-digit interval 10^9 <= n < 10^10, yielding 3 additional terms.

The three 10-digit discoveries are:

1938285196 -> 1699318528
2240563518 -> 2821450356
2952612351 -> 2195532261

The independent verifier was run on all 22 listed pairs and returned 22 verified matches with 0 non-verified outcomes.

No claim of completeness beyond 10^10 is made in this package.
