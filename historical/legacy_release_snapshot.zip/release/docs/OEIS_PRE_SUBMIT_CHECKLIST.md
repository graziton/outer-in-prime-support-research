# OEIS entry preparation checklist

## Current draft

The proposed sequence is the increasing list of positive integers m such that:

- m does not end in 0 (primitive restriction used for this sequence);
- m != T(m);
- rad(m) = rad(T(m));
- T is the outer-in decimal digit permutation.

Offset is 1.

The displayed data contain all 22 primitive terms below 10^10.

## Data

- [x] 22 terms independently verified.
- [x] Canonical b-file created.
- [x] b-file uses consecutive indices 1..22.
- [x] Search range and primitive restriction are stated explicitly.
- [x] Related reversal sequences are distinguished from the present transformation.

## Before submission

- [ ] Perform one final exact OEIS database search using several term prefixes and individual terms.
- [ ] Finalize author/signature information.
- [ ] Decide whether to upload the b-file or leave the 22 terms in the main data section.
- [ ] Decide whether to attach the search program as an associated source file.
- [ ] Final manuscript/reference wording should be consistent with the OEIS entry.

## Scope

No claim is made here that the full infinite sequence has been classified beyond 10^10.
